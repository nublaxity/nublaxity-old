<?php
/*
Plugin Name: Social Login myCRED Integration by Heateor
Plugin URI: https://www.heateor.com/social-login-mycred-integration
Description: Reward myCred points to your users for Social Login
Version: 1.2.8
Author: Team Heateor
Author URI: https://www.heateor.com
License: GPL2+
*/
defined( 'ABSPATH' ) or die( "Cheating........Uh!!" );
define( 'HEATEOR_SOCIAL_LOGIN_MYCRED_INTEGRATION_VERSION', '1.2.8' );
define( 'HEATEOR_SOCIAL_LOGIN_MYCRED_INTEGRATION_SLUG', 'social-login-heateor-myCRED-integration' );

$heateor_slmi_options = get_option( 'heateor_slmi' );
$heateor_slmi_license_options = get_option( 'heateor_slmi_license' );

if ( is_admin() && isset( $heateor_slmi_license_options['license_key'] ) && $heateor_slmi_license_options['license_key'] != '' ) {
	require 'library/plugin-update-checker/plugin-update-checker.php';
	$htMyUpdateChecker = PucFactory::buildUpdateChecker(
	    'https://www.heateor.com/api/license-manager/v1/info?l=' . $heateor_slmi_license_options['license_key'] . '&w=' . urlencode( str_replace( array( 'http://', 'https://' ), '', site_url() ) ),
	    __FILE__,
	    strtolower( HEATEOR_SOCIAL_LOGIN_MYCRED_INTEGRATION_SLUG )
	);
}

/**
 * Update options, version on basis of version comparison
 */
function heateor_slmi_update_db_check() {
	if ( get_option( 'heateor_slmi_version' ) != HEATEOR_SOCIAL_LOGIN_MYCRED_INTEGRATION_VERSION ) {
		update_option( 'heateor_slmi_version', HEATEOR_SOCIAL_LOGIN_MYCRED_INTEGRATION_VERSION );
	}
}
add_action( 'plugins_loaded', 'heateor_slmi_update_db_check' );

/**
 * Create plugin menu in admin.
 */	
function heateor_slmi_create_admin_menu() {
	$options_page = add_menu_page( 'Heateor - Social Login myCRED Integration', '<b>Social Login - myCRED Integration</b>', 'manage_options', 'heateor-slmi', 'heateor_slmi_option_page', plugins_url( 'images/logo.png', __FILE__ ) );
	$license_page = add_submenu_page( 'heateor-slmi', 'License Settings', 'License Settings', 'manage_options', 'heateor-slmi-license-settings', 'heateor_slmi_license_settings_page' );
	add_action( 'admin_print_scripts-' . $options_page, 'heateor_slmi_admin_scripts' );
	add_action( 'admin_print_scripts-' . $options_page, 'heateor_slmi_admin_style' );
	add_action( 'admin_print_scripts-' . $options_page, 'heateor_slmi_fb_sdk_script' );
	add_action( 'admin_print_scripts-' . $license_page, 'heateor_slmi_admin_scripts' );
	add_action( 'admin_print_scripts-' . $license_page, 'heateor_slmi_fb_sdk_script' );
	add_action( 'admin_print_styles-' . $license_page, 'heateor_slmi_admin_style' );
}
add_action( 'admin_menu', 'heateor_slmi_create_admin_menu' );

/**
 * Include javascript files in admin.
 */	
function heateor_slmi_admin_scripts() {
	?>
	<script>var heateorSlmiWebsiteUrl = '<?php echo site_url() ?>', heateorSlmiHelpBubbleTitle = "<?php echo __( 'Click to show help', 'heateor-slmi-text' ) ?>", heateorSlmiHelpBubbleCollapseTitle = "<?php echo __( 'Click to hide help', 'heateor-slmi-text' ) ?>"; </script>
	<?php
	wp_enqueue_script( 'heateor_slmi_admin_scripts', plugins_url( 'js/admin/admin.js', __FILE__ ), array( 'jquery' ) );
}

/**
 * Include CSS files in admin.
 */	
function heateor_slmi_admin_style() {
	wp_enqueue_style( 'heateor_slmi_admin_style', plugins_url( 'css/admin.css', __FILE__ ), false, HEATEOR_SOCIAL_LOGIN_MYCRED_INTEGRATION_VERSION );
}

/**
 * Include Javascript SDK in admin.
 */	
function heateor_slmi_fb_sdk_script() {
	wp_enqueue_script( 'heateor_slmi_fb_sdk_script', plugins_url( 'js/admin/fb_sdk.js', __FILE__ ), false, HEATEOR_SOCIAL_LOGIN_MYCRED_INTEGRATION_VERSION );
}

function heateor_slmi_plugin_settings_fields() {
	register_setting( 'heateor_slmi_options', 'heateor_slmi', 'heateor_slmi_validate_options' );
	register_setting( 'heateor_slmi_license_options', 'heateor_slmi_license', 'heateor_slmi_validate_options' );
}
add_action( 'admin_init', 'heateor_slmi_plugin_settings_fields' );

/**
 * Display notification message when plugin options are saved
 */
function heateor_slmi_settings_saved_notification() {
	if ( isset( $_GET['settings-updated'] ) && $_GET['settings-updated'] == 'true' ) {
		return '<div id="setting-error-settings_updated" class="updated settings-error notice is-dismissible below-h2"> 
<p><strong>' . __( 'Settings saved', 'heateor-slmi-text' ) . '</strong></p><button type="button" class="notice-dismiss"><span class="screen-reader-text">' . __( 'Dismiss this notice', 'heateor-slmi-text' ) . '</span></button></div>';
	}
}

/**
 * License Options page
 */
function heateor_slmi_license_settings_page() {
	global $heateor_slmi_license_options;
	echo heateor_slmi_settings_saved_notification();
	require 'admin/license-options.php';
}

/**
 * Plugin options page.
 */	
function heateor_slmi_option_page() {
	global $heateor_slmi_options;
	echo heateor_slmi_settings_saved_notification();
	require 'admin/plugin-options.php';
}

/** 
 * Validate plugin options
 */ 
function heateor_slmi_validate_options( $options ) {
	foreach ( $options as $k => $v ) {
		if ( is_string( $v ) ) {
			$options[$k] = trim( esc_attr( $v ) );
		}
	}
	return $options;
}

/**
 * Default options when plugin is activated
 */
function heateor_slmi_default_options() {
	// plugin version
	add_option( 'heateor_slmi_version', HEATEOR_SOCIAL_LOGIN_MYCRED_INTEGRATION_VERSION );
}
register_activation_hook( __FILE__, 'heateor_slmi_default_options' );

function heateor_slmi_license_notification() {
	if ( current_user_can( 'manage_options' ) ) {
		global $heateor_slmi_license_options;
		if ( ( ! isset( $heateor_slmi_license_options['license_key'] ) || $heateor_slmi_license_options['license_key'] == '' ) ) {
			?>
			<div class="error">
				<h3>Social Login - myCRED Integration</h3>
				<p><?php _e( 'Save license key at <strong>Social Login - myCRED Integration > License Settings</strong> page to enable plugin updates', 'heateor-slmi-text' ) ?><a style="margin-left: 8px" href="<?php echo admin_url() . 'admin.php?page=heateor-slmi-license-settings' ?>"><input type="button" class="button button-primary" value="<?php _e( 'Let\'s do it', 'heateor-slmi-text' ) ?>" /></a></p>
			</div>
			<?php
		}

		$heateor_slmi_last_update_check = get_option( 'external_updates-' . HEATEOR_SOCIAL_LOGIN_MYCRED_INTEGRATION_SLUG );
		if ( $heateor_slmi_last_update_check && ! empty( $heateor_slmi_last_update_check->update->upgrade_notice ) ) {
			?>
			<div class="error">
				<h3>Social Login - myCRED Integration</h3>
				<p><?php echo $heateor_slmi_last_update_check->update->upgrade_notice ?></p>
			</div>
			<?php
		}
	}
}
add_action( 'admin_notices', 'heateor_slmi_license_notification' );

/**
 * Register myCRED Hook
 */
function heateor_slmi_custom_hook( $installed ) {
	$installed['heateor_social_login'] = array(
		'title'       => __( 'Points for Social Login', 'heateor-slmi-text' ),
		'description' => __( 'Awards %_plural% for Social Login', 'heateor-slmi-text' ),
		'callback'    => array( 'heateor_social_login_myCRED' )
	);
	return $installed;
}
add_filter( 'mycred_setup_hooks', 'heateor_slmi_custom_hook' );

/**
 * Check if plugin is active
 */
function heateor_slmi_is_plugin_active( $plugin_file ) {
	return in_array( $plugin_file, apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) );
}

if ( ! class_exists( 'heateor_social_login_myCRED' ) && class_exists( 'myCRED_Hook' ) ) {
	class heateor_social_login_myCRED extends myCRED_Hook {
		// if custom myCRED integration is active
		private $custom_mycred = false;

		// if custom myCRED integration is active
		private $rewarded_for_signup = false;

		/**
		 * Construct
		 */
		function __construct( $hook_prefs ) {
			parent::__construct( array(
				'id'       => 'heateor_social_login',
				'defaults' => array(
					'first_social_login'   => '',
					'Facebook_creds'   => 1,
					'Facebook_log'     => '%plural% for login via Facebook',
					'Twitter_creds'   => 1,
					'Twitter_log'     => '%plural% for login via Twitter',
					'Linkedin_creds'   => 1,
					'Linkedin_log'     => '%plural% for login via Linkedin',
					'Google_creds'   => 1,
					'Google_log'     => '%plural% for login via Google',
					'Vkontakte_creds'   => 1,
					'Vkontakte_log'     => '%plural% for login via Vkontakte',
					'Xing_creds'   => 1,
					'Xing_log'     => '%plural% for login via Xing',
					'Instagram_creds'   => 1,
					'Instagram_log'     => '%plural% for login via Instagram',
					'Twitch_creds'   => 1,
					'Twitch_log'     => '%plural% for login via Twitch',
					'Steam_creds'   => 1,
					'Steam_log'     => '%plural% for login via Steam',
					'LiveJournal_creds'   => 1,
					'LiveJournal_log'     => '%plural% for login via LiveJournal',
					'limit_count'   => 1,
					'limit'     => 'hour',
				)
			), $hook_prefs );
		}

		/**
		 * Hook into WordPress
		 */
		public function run() {
			if ( heateor_slmi_is_plugin_active( 'heateor-custom-mycred-integration/heateor-custom-mycred-integration.php' ) ) {
				$this->custom_mycred = true;
				add_action( 'the_champ_user_successfully_created', array( $this, 'reward_registration_points' ), 10, 3 );
				add_action( 'the_champ_login_user', array( $this, 'reward_login_points' ), 10, 4 );
			} else {
				if ( isset( $this->prefs['first_social_login'] ) && $this->prefs['first_social_login'] == '1' ) {
					add_action( 'the_champ_user_successfully_created', array( $this, 'reward_registration_points' ), 10, 3 );
				} else {
					add_action( 'the_champ_login_user', array( $this, 'reward_login_points' ), 10, 4 );
				}
			}
		}

		/**
		 * Reward points based on the social network used for Social Login
		 */
		public function reward_points( $user_id, $social_network, $profile_data, $action = 'login' ) {
			if ( $action == 'signup' && $this->custom_mycred ) {
				$this->rewarded_for_signup = true;
			} elseif ( $action == 'login' && $this->custom_mycred && $this->rewarded_for_signup ) {
				return;
			}
			// Check if user is excluded
			if ( $this->core->exclude_user( $user_id ) ) return;

			if ( $social_network != '' && $user_id ) {
				$log_entry = $this->prefs[ucfirst( $social_network ) . '_log'];
				if ( $this->prefs['limit_count'] == '' ) {
					$this -> log_entry( $social_network, $log_entry, $user_id, $profile_data, $action );
				} else {
					global $wpdb;
					$prev_entry_time = $wpdb -> get_var( $wpdb -> prepare( "SELECT time FROM " . $wpdb->prefix . "myCRED_log WHERE ref = 'heateor_social_login' and user_id = %d and entry = %s ORDER BY id DESC LIMIT 1", $user_id, $log_entry ) );
					if ( $prev_entry_time ) {
						$limit = $this->prefs['limit'];
						$multiplier = 1;
						switch ( $limit ) {
							case 'minute':
								$multiplier = 60;
								break;
							
							case 'hour':
								$multiplier = 3600;
								break;

							case 'day':
								$multiplier = 3600*24;
								break;

							default:
								$multiplier = 1;
								break;
						}
						if ( $prev_entry_time + ( $multiplier*$this->prefs['limit_count'] ) < time() ) {
							$this -> log_entry( $social_network, $log_entry, $user_id, $profile_data, $action );
						}
					} else {
						$this -> log_entry( $social_network, $log_entry, $user_id, $profile_data, $action );
					}
				}
			}
		}

		/**
		 * Reward points for Social Login
		 */
		public function reward_login_points( $user_id, $profile_data, $social_id, $update ) {
			$this->reward_points( $user_id, isset( $profile_data['provider'] ) ? $profile_data['provider'] : '', $profile_data, 'login' );
		}

		/**
		 * Reward points for Social Registration
		 */
		public function reward_registration_points( $user_id, $user_data, $profile_data ) {
			$this->reward_points( $user_id, isset( $profile_data['provider'] ) ? $profile_data['provider'] : '', $profile_data, 'signup' );
		}

		/**
		 * Make entry in log table
		 */
		public function log_entry( $provider, $log_entry, $user_id, $profile_data, $action ) {
			$creds = $this->prefs[ucfirst( $provider ) . '_creds'];
			if ( $action == 'login' && isset( $this->prefs['first_social_login'] ) && $this->prefs['first_social_login'] == '1' ) {
				$creds = 0;
			}
			$creds = apply_filters( 'heateor_slmi_customize_creds', $creds, $provider, $log_entry, $user_id, $profile_data, $action );
			if ( is_array( $creds ) ) {
				foreach ( $creds as $cred ) {
					$this->core->add_creds(
						$cred['reference'],
						$user_id,
						$cred['creds'],
						$cred['log_entry']
					);
				}
			} elseif ( $creds !== 0 ) {
				$this->core->add_creds(
					'heateor_social_login',
					$user_id,
					$creds,
					$log_entry
				);
			}
		}

		/**
		 * Add Settings
		 */
		public function preferences() {
			// Our settings are available under $this->prefs
			$prefs = $this->prefs;
			global $theChampLoginOptions;
			if ( isset( $theChampLoginOptions ) ) {
				$login_networks = isset( $theChampLoginOptions['providers'] ) ? $theChampLoginOptions['providers'] : array();
				if ( $login_networks ) {
					?>
					<p><strong>Note: </strong><?php _e( 'Following points will be awarded in addition to the "Points for logins" (if enabled)', 'heateor-slmi-text' ); ?></p>
					<!-- Award points on first social login -->
					<ol>
						<li>
							<div class="h2"><input type="checkbox" style="margin-top:0px;float:left" name="<?php echo $this->field_name( 'first_social_login' ); ?>" id="<?php echo $this->field_id( 'first_social_login' ); ?>" <?php echo isset( $prefs['first_social_login'] ) && $prefs['first_social_login'] == 1 ? 'checked' : '' ?> value="1" /><label for="<?php echo $this->field_id( 'first_social_login' ); ?>" class="subheader"><?php _e( 'Award points only on new user registration via Social Login (first Social Login)', 'heateor-slmi-text' ); ?></label></div>
						</li>
					</ol>
					<?php
					foreach ( $login_networks as $network ) {
						$network = ucfirst( $network );
						?>
						<!-- First we set the amount -->
						<label class="subheader"><?php echo $this->core->plural() . ' for ' . $network . ' login'; ?></label>
						<ol>
							<li>
								<div class="h2"><input type="text" name="<?php echo $this->field_name( $network . '_creds' ); ?>" id="<?php echo $this->field_id( $network . '_creds' ); ?>" value="<?php echo $this->core->format_number( isset( $prefs[$network . '_creds'] ) ? $prefs[$network . '_creds'] : 1 ); ?>" size="8" /></div>
							</li>
						</ol>
						<!-- Then the log template -->
						<label class="subheader"><?php _e( 'Log template', 'mycred' ); ?></label>
						<ol>
							<li>
								<div class="h2"><input type="text" name="<?php echo $this->field_name( $network . '_log' ); ?>" id="<?php echo $this->field_id( $network . '_log' ); ?>" value="<?php echo isset( $prefs[$network . '_log'] ) ? $prefs[$network . '_log'] : '%plural% for ' . $network . ' login'; ?>" class="long" /></div>
							</li>
						</ol>
						<?php
					}
				} else {
					echo '<h3 style="color:red">';
					_e( 'Choose Social Login networks in Super Socializer plugin to see the options', 'heateor-slmi-text' );
					echo '</h3>';
				}

				if ( $login_networks ) {
					?>
					<h2><?php _e( 'Limit', 'heateor-slmi-text' ); ?></h2>
					<hr/>
					<label class="subheader"><?php _e( 'For logging in using the same social network, award points per (leave empty for no limit) ', 'heateor-slmi-text' ); ?></label>
					<ol>
						<li>
							<div class="h2" style="float:left"><input style="width:40px" type="text" name="<?php echo $this->field_name( 'limit_count' ); ?>" id="<?php echo $this->field_id( 'limit_count' ); ?>" value="<?php echo isset( $prefs['limit_count'] ) ? $prefs['limit_count'] : 1; ?>" /></div>
							<div class="h2" style="float:left"><select style="height:24px" name="<?php echo $this->field_name( 'limit' ); ?>" id="<?php echo $this->field_id( 'limit' ); ?>" >
								<option value="second" <?php echo isset( $prefs['limit'] ) && $prefs['limit'] == 'second' ? 'selected' : '' ?>><?php _e( 'Second(s)', 'heateor-slmi-text' ) ?></option>
								<option value="minute" <?php echo isset( $prefs['limit'] ) && $prefs['limit'] == 'minute' ? 'selected' : '' ?>><?php _e( 'Minute(s)', 'heateor-slmi-text' ) ?></option>
								<option value="hour" <?php echo !isset( $prefs['limit'] ) || $prefs['limit'] == 'hour' ? 'selected' : '' ?>><?php _e( 'Hour(s)', 'heateor-slmi-text' ) ?></option>
								<option value="day" <?php echo isset( $prefs['limit'] ) && $prefs['limit'] == 'day' ? 'selected' : '' ?>><?php _e( 'Day(s)', 'heateor-slmi-text' ) ?></option>
							</select></div>
						</li>
					</ol>
					<div style="clear:both"></div>
					<?php
				}

			} else {
				echo '<h3 style="color:red">';
				_e( 'Activate Super Socializer plugin to see the options', 'heateor-slmi-text' );
				echo '</h3>';
			}
		}

		/**
		 * Sanitize Preferences
		 */
		public function sanitise_preferences( $data ) {
			$new_data = $data;
			global $theChampLoginOptions;
			if ( isset( $theChampLoginOptions ) ) {
				$login_networks = isset( $theChampLoginOptions['providers'] ) ? $theChampLoginOptions['providers'] : array();

				foreach ( $login_networks as $network ) {
					$network = ucfirst( $network );
					$new_data[$network . 'log'] = ( ! empty( $data[$network . 'log'] ) ) ? sanitize_text_field( $data[$network . 'log'] ) : $this->defaults[$network . 'log'];
				}
			}

			return $new_data;
		}
	}
}

/**
 * Show points for Social Login with other points being displayed via "mycred_hook_table" shortcode
 */
function heateor_slmi_social_login_points( $content, $atts ) {
	$hooks = get_option( 'mycred_pref_hooks' );
	if ( isset( $hooks['active'] ) && strpos( $content, '<table' ) !== false ) {
		$content = str_replace( array( '</tbody>', '</table>' ), '', $content );
		if (in_array( 'heateor_social_login', $hooks['active'] ) && isset( $hooks['hook_prefs']['heateor_social_login'] ) ) {
			foreach ( $hooks['hook_prefs']['heateor_social_login'] as $key => $val ) {
				if ( $val > 0 && strpos( $key, 'creds' ) !== false ) {
					$key = str_replace( array( '_', 'creds' ), array( ' ', 'Login' ), $key );
					$content .= '<tr>';
					$content .= '<td class="column-instance">Points for ' . $key . '</td>';
					$content .= '<td class="column-amount" colspan="2">' . $val . '</td>';
					$content .= '</tr>';
				}
			}
		}
		if ( isset( $hooks['hook_prefs']['heateor_social_login']['limit_count'] ) && isset( $hooks['hook_prefs']['heateor_social_login']['limit'] ) ) {
			$content .= '<tr>';
			$content .= '<td class="column-instance">Limit (Points for Social Login)</td>';
			$content .= '<td class="column-amount" colspan="2">Maximum once per ' . ( $hooks['hook_prefs']['heateor_social_login']['limit_count'] == 1 ? '' : $hooks['hook_prefs']['heateor_social_login']['limit_count'] ) . " " . $hooks['hook_prefs']['heateor_social_login']['limit'] . '(s)</td>';
			$content .= '</tr>';
		}
		$content .= '</tbody></table>';
	}
	return $content;
}
add_filter( 'mycred_render_hook_table', 'heateor_slmi_social_login_points', 10, 2 );

/**
 * Add add-on reference
 */
function heateor_slmi_add_addon_reference( $list ) {
	$list['heateor_social_login'] = 'Heateor Social Login';
	return $list;
}
add_filter( 'mycred_all_references', 'heateor_slmi_add_addon_reference' );