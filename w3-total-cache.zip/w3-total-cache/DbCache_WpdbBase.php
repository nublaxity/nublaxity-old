<?php
namespace W3TC;

require_once ABSPATH . 'wp-includes/wp-db.php';

class DbCache_WpdbBase extends \wpdb {
}
