<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'restricted access' );
}

/*
 * This is a file for admin functionality.
 */
include_once WP_API_MUS_PLUGIN_PATH . 'includes/admin/admin.php';

/*
 * This is a file for core functions.
 */
include_once WP_API_MUS_PLUGIN_PATH . 'includes/functions.php';

/*
 * This is a class file for WordPress API.
 */
include_once WP_API_MUS_PLUGIN_PATH . 'includes/class-api.php';