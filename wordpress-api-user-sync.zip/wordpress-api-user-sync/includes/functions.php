<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'restricted access' );
}

/*
 * This is a function that determine current user.
 * $user variable return user data.
 */
if ( ! function_exists( 'wp_api_mus_determine_current_user' ) ) {
    add_filter( 'determine_current_user', 'wp_api_mus_determine_current_user', 20 );
    function wp_api_mus_determine_current_user( $user ) {
        
        global $wp_json_basic_auth_error;
        
        $wp_json_basic_auth_error = null;

        if ( ! empty( $user ) ) {
            return $user;
        }

        if ( !isset( $_SERVER['PHP_AUTH_USER'] ) ) {
            return $user;
        }
        
        $username = $_SERVER['PHP_AUTH_USER'];
        $password = $_SERVER['PHP_AUTH_PW'];

        remove_filter( 'determine_current_user', 'wp_api_mus_determine_current_user', 20 );
        
        $user = wp_authenticate( $username, $password );
        if ( isset( $user->ID ) && $user->ID ) {
            if ( user_can( $user->ID, 'administrator' ) ) {
                // nothing.
            } else {
                $user = wp_authenticate( time().uniqid(), uniqid().time() );
            }
        }
        
        add_filter( 'determine_current_user', 'wp_api_mus_determine_current_user', 20 );
        
        if ( is_wp_error( $user ) ) {
            $wp_json_basic_auth_error = $user;
            return null;
        }
        
        $wp_json_basic_auth_error = true;
        
        return $user->ID;
    }
}

/*
 * This is a function that fire REST API error.
 * $error variable return error data.
 */
if ( ! function_exists( 'wp_api_mus_rest_authentication_errors' ) ) {
    add_filter( 'rest_authentication_errors', 'wp_api_mus_rest_authentication_errors' );
    function wp_api_mus_rest_authentication_errors( $error ) {
        
        if ( ! empty( $error ) ) {
            return $error;
        }
        
        global $wp_json_basic_auth_error;
        
        return $wp_json_basic_auth_error;
    }
}

/*
 * This is a function that insert REST API user.
 * $user variable return user data.
 * $request variable return request data.
 * $create variable return create data.
 */
if ( ! function_exists( 'wp_api_mus_rest_insert_user' ) ) {
    add_action( 'rest_insert_user', 'wp_api_mus_rest_insert_user', 20, 3 );
    function wp_api_mus_rest_insert_user( $user, $request, $create ) {
        
        global $wpdb;
        
        if ($request['meta']) {
            $user_id = $user->ID;
            foreach ( $request['meta'] as $key => $value ) {
                if ( $key == 'mustempdata' ) {
                    $wpdb->update(
                        $wpdb->base_prefix.'users',
                        array(
                            'user_pass' => $value,
                        ),
                        array(
                            'ID'    => $user_id,
                        )
                    );
                } else {
                    update_user_meta( $user_id, $key, $value );
                }
            }
        }
    }
}

/*
 * This is a function that register custom REST API call.
 */
if ( ! function_exists( 'wp_api_mus_register_rest_route' ) ) {
    add_action( 'rest_api_init', 'wp_api_mus_register_rest_route' );
    function wp_api_mus_register_rest_route() {
        
        register_rest_route(
            'wp_api_mus',
            '/prefix',
            array(
                'methods'   => 'GET',
                'callback'  => 'wp_api_mus_prefix',
            )
        );
    }
}

/*
 * This is a function that return prefix.
 */
if ( ! function_exists( 'wp_api_mus_prefix' ) ) {
    function wp_api_mus_prefix() {
        
        global $wpdb;
        
        return $wpdb->prefix;
    }
}

/*
 * This is a function that crypt data.
 * $string variable return original data.
 * $action variable return crypt type.
 */
if ( ! function_exists( 'wp_api_mus_crypt' ) ) {
    function wp_api_mus_crypt( $string, $action = 'e' ) {
        
        if ( extension_loaded( 'openssl' ) ) {
            $secret_key = 'wp_api_mus_key';
            $secret_iv = 'wp_api_mus_iv';

            $output = false;
            $encrypt_method = 'AES-256-CBC';
            $key = hash( 'sha256', $secret_key );
            $iv = substr( hash( 'sha256', $secret_iv ), 0, 16 );

            if( $action == 'e' ) {
                $output = base64_encode( openssl_encrypt( $string, $encrypt_method, $key, 0, $iv ) );
            }
            else if( $action == 'd' ){
                $output = openssl_decrypt( base64_decode( $string ), $encrypt_method, $key, 0, $iv );
            }

            return $output;
        } else {
            return $string;
        }
    }
}

/*
 * This is a function that return user meta fields.
 */
if ( ! function_exists( 'wp_api_mus_user_meta_fields' ) ) {
    function wp_api_mus_user_meta_fields() {
        
        global $wpdb;

        $fields = array();
        $results = $wpdb->get_results( "SELECT DISTINCT meta_key FROM ".$wpdb->base_prefix."usermeta" );
        if ( $results != null ) {
            foreach ( $results as $result ) {
                if ( $result->meta_key != 'nickname' &&
                        $result->meta_key != 'first_name' &&
                        $result->meta_key != 'last_name' &&
                        $result->meta_key != 'description' &&
                        $result->meta_key != 'locale' &&
                        $result->meta_key != 'session_tokens' &&
                        $result->meta_key != 'musrel'
                ) {
                    $fields[] = $result->meta_key;
                }
            }
        }
        
        return $fields;
    }
}

/*
 * This is a function that show sync/unsync section.
 */
if ( ! function_exists( 'wp_api_mus_manual_sync' ) ) {
    add_action( 'show_user_profile', 'wp_api_mus_manual_sync' );
    add_action( 'edit_user_profile', 'wp_api_mus_manual_sync' );
    function wp_api_mus_manual_sync() {
        
        $sync_type = get_option( 'wp_api_mus_sync_type' );
        if ( $sync_type == 'manual' ) {
            ?>
                <h2><?php _e( 'WordPress API Multiple Sites User Sync' ); ?></h2>
                <table class="form-table">
                    <tbody>
                        <tr>
                            <th><label><?php _e( 'Manual Sync' ); ?></label></th>
                            <td><input type="submit" name="submit" class="button button-primary" value="Sync"></td>
                        </tr>
                    </tbody>
                </table>                
            <?php
        }
    }
}

/*
 * This is a function that run when user add/update/register.
 * $user_id variable return user id.
 */
if ( ! function_exists( 'wp_api_mus_integration_on_hooks' ) ) {
    add_action( 'user_register', 'wp_api_mus_integration_on_hooks', 99, 1 );
    add_action( 'edit_user_profile_update', 'wp_api_mus_integration_on_hooks', 99, 1 );
    add_action( 'profile_update', 'wp_api_mus_integration_on_hooks', 99, 1 );
    function wp_api_mus_integration_on_hooks( $user_id ) {
        
        $sync_type = get_option( 'wp_api_mus_sync_type' );
        $content_type = ( isset( $_SERVER['CONTENT_TYPE'] ) ? $_SERVER['CONTENT_TYPE'] : '' );
        $licence = get_site_option( 'wp_api_mus_licence' );
        if ( $content_type != 'application/json' && $sync_type == 'auto' && $licence ) {
            $sites = get_option( 'wp_api_mus_sites' );
            $fields = wp_api_mus_user_meta_fields();
            wp_api_mus_integration( $user_id, $sites, $fields );
        } else if ( $sync_type == 'manual' ) {
            if ( isset( $_REQUEST['submit'] ) && $_REQUEST['submit'] == 'Sync' ) {
                $sites = get_option( 'wp_api_mus_sites' );
                $fields = wp_api_mus_user_meta_fields();
                wp_api_mus_integration( $user_id, $sites, $fields );
            }
        }
    }
}

/*
 * This is a function that integrate user.
 * $user_id variable return user id.
 * $sites variable return sites data.
 * $fields variable return user meta fields.
 */
if ( ! function_exists( 'wp_api_mus_integration' ) ) {
    function wp_api_mus_integration( $user_id = 0, $sites = array(), $fields = array() ) {
        
        global $wpdb;
        
        if ( $sites != null ) {
            $user_info = get_userdata( $user_id );
            $data = array(
                'username'      => $user_info->user_login,
                'name'          => $user_info->display_name,
                'first_name'    => $user_info->first_name,
                'last_name'     => $user_info->last_name,
                'email'         => $user_info->user_email,
                'url'           => $user_info->user_url,
                'description'   => $user_info->description,
                'locale'        => $user_info->locale,
                'nickname'      => $user_info->nickname,
                'roles'         => $user_info->roles,          
            );
            
            $data['meta']['mustempdata'] = $user_info->user_pass;
            
            if ( $fields != null ) {
                foreach ( $fields as $field ) {
                    if ( isset( $user_info->{$field} ) ) {
                        $data['meta'][$field] = $user_info->{$field};
                    }
                }
            }
            
            $wp_api_mus = get_user_meta( $user_id, 'musrel', true );
            if ( ! is_array( $wp_api_mus ) ) {
                $wp_api_mus = array();
            }
            
            foreach ( $sites as $key => $value ) {
                $url = $key;
                $username = $value['username'];
                $password = wp_api_mus_crypt( $value['password'], 'd' );
                if ( $value['status'] ) {
                    $api = new WP_API_MUS( $url, $username, $password );
                    $destination_user_id = 0;
                    if ( isset( $wp_api_mus[$url] ) ) {
                        $destination_user_id = $wp_api_mus[$url];
                    } else {
                        $users = $api->getUsers( $user_info->user_email );
                        if ( $users != null && isset( $users[0]->id  ) ) {
                            $destination_user_id = $users[0]->id;
                        }
                    }
                    
                    if ( $data['meta'] != null ) {
                        $filter_meta = array();
                        foreach ( $data['meta'] as $meta_key => $meta_value ) {
                            $meta_key = str_replace( $wpdb->prefix, $value['prefix'], $meta_key );
                            $filter_meta[$meta_key] = $meta_value;
                        }
                        
                        $data['meta'] = $filter_meta;
                    }
                    
                    if ( $destination_user_id ) {
                        $user = $api->updateUser( $data, $destination_user_id );                        
                    } else {
                        $data['password'] = $user_info->user_pass;
                        $user = $api->addUser( $data );
                        if ( isset( $user->id ) ) {
                            $destination_user_id = $user->id;
                        }
                    }
                    
                    if ( $destination_user_id ) {
                        $wp_api_mus[$url] = $destination_user_id;
                    }
                }
            }
            
            update_user_meta( $user_id, 'musrel',  $wp_api_mus );
        }
    }
}