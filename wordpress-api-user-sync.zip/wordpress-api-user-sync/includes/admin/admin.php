<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'restricted access' );
}

/*
 * This is a function that add admin menu
 */
if ( ! function_exists( 'wp_api_mus_add_admin_menu' ) ) {
    add_action( 'admin_menu', 'wp_api_mus_add_admin_menu' );
    function wp_api_mus_add_admin_menu() {
        
        add_menu_page( 'WordPress API Multisite User Sync', 'User Sync', 'manage_options', 'wp_api_mus', 'wp_api_mus_callback', 'dashicons-update' );
        add_submenu_page( 'wp_api_mus', 'User Sync - Sites', 'Sites', 'manage_options', 'wp_api_mus', 'wp_api_mus_callback' );
        add_submenu_page( 'wp_api_mus', 'User Sync - Bulk Sync', 'Bulk Sync', 'manage_options', 'wp_api_mus_bulk_sync', 'wp_api_mus_bulk_sync_callback' );
        add_submenu_page( 'wp_api_mus', 'User Sync - Settings', 'Settings', 'manage_options', 'wp_api_mus_settings', 'wp_api_mus_settings_callback' );
        add_submenu_page( 'wp_api_mus', 'User Sync - Licence Verification', 'Licence Verification', 'manage_options', 'wp_api_mus_licence_verification', 'wp_api_mus_licence_verification_callback' );
    }
}

/*
 * This is a function that add and list sites.
 */
if ( ! function_exists( 'wp_api_mus_callback' ) ) {
    function wp_api_mus_callback() {        
        
        $page_url = menu_page_url( 'wp_api_mus', 0 );
        
        if ( isset( $_REQUEST['submit'] ) ) {
            $sites = get_option( 'wp_api_mus_sites' );
            if ( ! is_array( $sites ) ) {
                $sites = array();
            }
            
            $sites[$_REQUEST['url']] = array(
                'username'  => $_REQUEST['username'],
                'password'  => wp_api_mus_crypt( $_REQUEST['password'], 'e' ),
                'hash'      => md5( $_REQUEST['password'] ),
                'status'    => 1,
            );
            
            $api = new WP_API_MUS( $_REQUEST['url'], $_REQUEST['username'], $_REQUEST['password'] );
            $authentication = $api->authentication();
            if ( ! $authentication || isset( $authentication->code ) ) {
                ?>
                    <div class="notice notice-error is-dismissible">
                        <p><?php _e( 'Authentication failure.' ); ?></p>
                    </div>
                <?php
            } else {
                $sites[$_REQUEST['url']]['prefix'] = $authentication;
                update_option( 'wp_api_mus_sites', $sites );
                ?>
                    <div class="notice notice-success is-dismissible">
                        <p><?php _e( 'Site added successfully.' ); ?></p>
                    </div>
                <?php
            }
        } else if ( isset( $_REQUEST['update'] ) ) {
            $sites = get_option( 'wp_api_mus_sites' );
            $sites[$_REQUEST['url']] = array(
                'username'  => $_REQUEST['username'],
                'password'  => wp_api_mus_crypt( $_REQUEST['password'], 'e' ),
                'hash'      => md5( $_REQUEST['password'] ),
                'status'    => $_REQUEST['status'],
            );
            
            $api = new WP_API_MUS( $_REQUEST['url'], $_REQUEST['username'], $_REQUEST['password'] );
            $authentication = $api->authentication();
            if ( ! $authentication || isset( $authentication->code ) ) {
                ?>
                    <div class="notice notice-error is-dismissible">
                        <p><?php _e( 'Authentication failure.' ); ?></p>
                    </div>
                <?php
            } else {
                $sites[$_REQUEST['url']]['prefix'] = $authentication;
                update_option( 'wp_api_mus_sites', $sites );
                ?>
                    <div class="notice notice-success is-dismissible">
                        <p><?php _e( 'Site added successfully.' ); ?></p>
                    </div>
                <?php
            }
        } else if ( isset( $_REQUEST['delete'] ) ) {
            $sites = get_option( 'wp_api_mus_sites' );
            unset( $sites[$_REQUEST['delete']] );
            update_option( 'wp_api_mus_sites', $sites );
            ?>
                <div class="notice notice-success is-dismissible">
                    <p><?php _e( 'Site removed successfully.' ); ?></p>
                </div>
            <?php
        } else {
            // nothing
        }
        
        $licence = get_site_option( 'wp_api_mus_licence' );
        ?>
            <div class="wrap">
                <h1><?php _e( 'Sites' ); ?></h1>
                <hr>
                <?php
                if ( $licence ) {
                    if ( isset( $_REQUEST['edit'] ) ) {
                        $sites = get_option( 'wp_api_mus_sites' );
                        $site = $sites[$_REQUEST['edit']];
                        ?>
                            <h2><?php _e( 'Edit site:' ); ?> <?php echo $_REQUEST['edit']; ?></h2>                           
                            <form method="post" action="<?php echo $page_url; ?>">
                                <table class="form-table">
                                    <tbody>
                                        <tr>
                                            <th scope="row"><label><?php _e( 'Status' ); ?></label></th>
                                            <td>
                                                <input type="hidden" name="status" value="0" />
                                                <input type="checkbox" name="status" value="1"<?php echo ( $site['status'] ? ' checked="checked"' : '' ); ?> />
                                            </td>
                                        </tr>
                                        <tr>
                                            <th scope="row"><label><?php _e( 'Username' ); ?> <span class="description">(required)</span></label></th>
                                            <td>
                                                <input type="text" name="username" value="<?php echo $site['username']; ?>" required />
                                            </td>
                                        </tr>
                                        <tr>
                                            <th scope="row"><label><?php _e( 'Password' ); ?> <span class="description">(required)</span></label></th>
                                            <td>
                                                <input type="password" name="password" value="" required />
                                            </td>
                                        </tr>                                        
                                    </tbody>
                                </table>
                                <p>
                                    <input type="hidden" name="url" value="<?php echo $_REQUEST['edit']; ?>" />
                                    <input type='submit' class='button-primary' name="update" value="<?php _e( 'Update site' ); ?>" />
                                </p>
                            </form>
                        <?php
                    } else {
                        ?>
                            <h2><?php _e( 'Add site' ); ?></h2>                            
                            <form method="post" action="<?php echo $page_url; ?>">
                                <table class="form-table">
                                    <tbody>                                            
                                        <tr>
                                            <th scope="row"><label><?php _e( 'Site URL' ); ?> <span class="description">(required)</span></label></th>
                                            <td>
                                                <input type="url" name="url" class="regular-text code" required />
                                            </td>
                                        </tr>
                                        <tr>
                                            <th scope="row"><label><?php _e( 'Username' ); ?> <span class="description">(required)</span></label></th>
                                            <td>
                                                <input type="text" name="username" required />
                                            </td>
                                        </tr>
                                        <tr>
                                            <th scope="row"><label><?php _e( 'Password' ); ?> <span class="description">(required)</span></label></th>
                                            <td>
                                                <input type="password" name="password" required />
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                                <p><input type='submit' class='button-primary' name="submit" value="<?php _e( 'Add site' ); ?>" /></p>
                            </form>
                            <br>
                            <h2><?php _e( 'Sites' ); ?></h2>                            
                            <table class="widefat striped">
                                <thead>
                                    <tr>
                                        <th><?php _e( 'Site URL' ); ?></th>
                                        <th><?php _e( 'Status' ); ?></th>       
                                        <th><?php _e( 'Action' ); ?></th>
                                    </tr>
                                </thead>
                                <tfoot>
                                    <tr>
                                        <th><?php _e( 'Site URL' ); ?></th>
                                        <th><?php _e( 'Status' ); ?></th>       
                                        <th><?php _e( 'Action' ); ?></th>
                                    </tr>
                                </tfoot>
                                <tbody>
                                    <?php
                                        $sites = get_option( 'wp_api_mus_sites' );
                                        if ( $sites != null ) {
                                            foreach ( $sites as $site => $data ) {
                                                ?>
                                                    <tr>
                                                        <td><?php echo $site; ?></td>
                                                        <td>
                                                            <?php
                                                                if ( $data['status'] ) {
                                                                    ?><span class="dashicons dashicons-yes"></span><?php
                                                                } else {
                                                                    ?><span class="dashicons dashicons-no"></span><?php
                                                                }
                                                            ?>
                                                        </td>
                                                        <td>
                                                            <a href="<?php echo $page_url; ?>&edit=<?php echo $site; ?>"><span class="dashicons dashicons-edit"></span></a>
                                                            <a href="<?php echo $page_url; ?>&delete=<?php echo $site; ?>"><span class="dashicons dashicons-trash"></span></a>
                                                        </td>
                                                    </tr>
                                                <?php
                                            }
                                        } else {
                                            ?>
                                                <tr>
                                                    <td colspan="3"><?php _e( 'No sites found.' ); ?></td>
                                                </tr>
                                            <?php
                                        }
                                    ?>                        
                                </tbody>
                            </table>
                        <?php
                    }
                } else {
                    ?>
                        <div class="notice notice-error is-dismissible">
                            <p><?php _e( 'Please verify purchase code.' ); ?></p>
                        </div>
                    <?php
                }
                ?>
            </div>
        <?php
    }
}

/*
 * This is a function that sync bulk users.
 */
if ( ! function_exists( 'wp_api_mus_bulk_sync_callback' ) ) {
    function wp_api_mus_bulk_sync_callback() {
        
        $record_per_page = 10;
        if ( isset( $_REQUEST['wp_api_mus_record_per_page'] ) ) {
            $record_per_page = (int) $_REQUEST['wp_api_mus_record_per_page'];
        }
       
        if ( isset( $_REQUEST['submit'] ) ) {
            $sites = get_option( 'wp_api_mus_sites' );
            $fields = wp_api_mus_user_meta_fields();
            $records = ( isset( $_REQUEST['records'] ) ? $_REQUEST['records'] : array() );
            if ( $records != null ) {
                foreach ( $records as $record ) {
                    $user_id = (int) $record;
                    wp_api_mus_integration( $user_id, $sites, $fields );
                }
            }
        }
        
        $page_url = admin_url( '/admin.php?page=wp_api_mus_bulk_sync' );
        $licence = get_site_option( 'wp_api_mus_licence' );
        ?>
            <div class="wrap">     
                <h1><?php _e( 'Bulk Sync' ); ?></h1>
                <hr>
                <?php
                    if ( $licence ) {
                        ?>
                        <form method="post">                
                            <table class="form-table">
                                <tbody>
                                    <tr>
                                        <th scope="row"><?php _e( 'User Per Page' ); ?></th>
                                        <td>
                                            <input type="number" name="wp_api_mus_record_per_page" min="1" value="<?php echo $record_per_page; ?>" />
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <p class="submit"><input name="filter" class="button button-secondary" value="<?php _e( 'Filter' ); ?>" type="submit"></p>
                        </form>                
                        <form method="post" action="<?php echo $page_url; ?>">
                            <p class="search-box wp_api_mus-search-box">
                                <label class="screen-reader-text" for="post-search-input"><?php _e( 'Search Users:' ); ?></label>
                                <input id="post-search-input" name="s" value="<?php echo ( isset( $_REQUEST['s'] ) ? $_REQUEST['s'] : ''  ); ?>" type="search">
                                <input id="search-submit" class="button" value="<?php _e( 'Search Users' ); ?>" type="submit">
                            </p>
                            <table class="wp-list-table widefat fixed striped">
                                <thead>
                                    <tr>
                                        <td class="manage-column column-cb check-column"><input type="checkbox"></td>
                                        <th><?php _e( 'Name' ); ?></th>
                                        <th><?php _e( 'Email' ); ?></th>
                                    </tr>
                                </thead>
                                <tfoot>
                                    <tr>
                                        <td class="manage-column column-cb check-column"><input type="checkbox"></td>
                                        <th><?php _e( 'Name' ); ?></th>
                                        <th><?php _e( 'Email' ); ?></th>
                                    </tr>
                                </tfoot>
                                <tbody>
                                    <?php 
                                        $paged = ( isset( $_REQUEST['paged'] ) ) ? $_REQUEST['paged'] : 1;
                                        $add_args = array(
                                            'wp_api_mus_record_per_page'  => $record_per_page,
                                        );

                                        $args = array(
                                            'number'    => $record_per_page,                                    
                                            'paged'     => $paged,
                                        );

                                        if ( isset( $_REQUEST['s'] ) ) {
                                            $args['search'] = $_REQUEST['s'];
                                            $args['search_columns'] = array(
                                                'ID',
                                                'user_login',
                                                'user_nicename',
                                                'user_email',
                                                'user_url',
                                            );
                                            $add_args['s'] = $_REQUEST['s'];
                                        }

                                        $user_query = new WP_User_Query( $args );
                                        $records = $user_query->get_results();
                                        if ( $records != null ) {
                                            $module = get_option( 'wp_api_mus_module' );
                                            foreach ( $records as $record ) {                                                
                                                ?>
                                                    <tr>
                                                        <th class="check-column"><input type="checkbox" name="records[]" value="<?php echo $record->ID; ?>"></th>
                                                        <td class="title column-title page-title">
                                                            <strong><a href="<?php echo get_edit_user_link( $record->ID ); ?>"><?php echo $record->data->display_name; ?></a></strong>
                                                            <?php
                                                                $musrel = get_user_meta( $record->ID, 'musrel', true );
                                                                if ( $musrel != null ) {
                                                                    ?><p><strong style="display: inline-block;"><?php _e( 'Synced:' ); ?></strong> <?php echo implode( ', ', array_keys( $musrel ) ); ?></p><?php
                                                                }
                                                            ?>
                                                        </td>
                                                        <td><?php echo $record->user_email; ?></td>
                                                    </tr>
                                                <?php
                                            }
                                        } else {
                                            ?>
                                                <tr class="no-items">                                       
                                                    <td class="colspanchange" colspan="3"><?php _e( 'No users found.' ); ?></td>
                                                </tr>
                                            <?php
                                        }
                                    ?>
                                </tbody>
                            </table>
                            <?php
                                if ( $user_query->get_total() >= $record_per_page ) {
                                    ?>
                                        <div class="wp_api_mus-pagination">
                                            <span class="pagination-links">
                                                <?php
                                                $big = 999999999;
                                                $total = ceil( $user_query->get_total() / $record_per_page );
                                                $paginate_url = admin_url( '/admin.php?page=wp_api_mus_bulk_sync&paged=%#%' );
                                                echo paginate_links( array(
                                                    'base'      => str_replace( $big, '%#%', $paginate_url ),
                                                    'format'    => '?paged=%#%',
                                                    'current'   => max( 1, $paged ),
                                                    'total'     => $total,
                                                    'add_args'  => $add_args,    
                                                    'prev_text' => __( '&laquo;' ),
                                                    'next_text' => __( '&raquo;' ),
                                                ) );
                                                ?>
                                            </span>
                                        </div>
                                    <?php
                                }
                            ?>
                            <p class="submit">
                                <input type="hidden" name="wp_api_mus_record_per_page" value="<?php echo $record_per_page; ?>" />
                                <input name="submit" class="button button-primary" value="<?php _e( 'Sync' ); ?>" type="submit">
                            </p>
                        </form>
                        <style>
                            .wp_api_mus-pagination {
                                color: #555;
                                cursor: default;
                                float: right;
                                height: 28px;
                                margin-top: 3px;
                            }

                            .wp_api_mus-pagination .page-numbers {
                                background: #e5e5e5;
                                border: 1px solid #ddd;
                                display: inline-block;
                                font-size: 16px;
                                font-weight: 400;
                                line-height: 1;
                                min-width: 17px;
                                padding: 3px 5px 7px;
                                text-align: center;
                                text-decoration: none;
                            }

                            .wp_api_mus-pagination .page-numbers.current {
                                background: #f7f7f7;
                                border-color: #ddd;
                                color: #a0a5aa;
                                height: 16px;
                                margin: 6px 0 4px;
                            }

                            .wp_api_mus-pagination a.page-numbers:hover {
                                background: #00a0d2;
                                border-color: #5b9dd9;
                                box-shadow: none;
                                color: #fff;
                                outline: 0 none;
                            }

                            .wp_api_mus-search-box {
                                margin-bottom: 8px !important;
                            }

                            @media screen and (max-width:782px) {
                                .wp_api_mus-pagination {
                                    float: none;
                                    height: auto;
                                    text-align: center;
                                    margin-top: 7px;
                                }

                                .wp_api_mus-search-box {
                                    margin-bottom: 20px !important;
                                }
                            }
                        </style>
                        <?php
                    } else {
                        ?>
                            <div class="notice notice-error is-dismissible">
                                <p><?php _e( 'Please verify purchase code.' ); ?></p>
                            </div>
                        <?php
                    }
                ?>
            </div>
        <?php
    }
}

/*
 * This is a function for plugin settings.
 */
if ( ! function_exists( 'wp_api_mus_settings_callback' ) ) {
    function wp_api_mus_settings_callback() {
        
        if ( isset( $_REQUEST['submit'] ) ) {
            $request = $_REQUEST;
            unset( $request['page'] );
            unset( $request['submit'] );
            if ( $request != null ) {
                foreach ( $request as $key => $value ) {
                    update_option( $key, $value );
                }
            }
        }
        
        $sync_type = get_option( 'wp_api_mus_sync_type' );
        $licence = get_site_option( 'wp_api_mus_licence' );
        ?>
            <div class="wrap">     
                <h1><?php _e( 'Settings' ); ?></h1>
                <hr>
                <?php
                    if ( $licence ) {
                        ?>
                            <form method="post">                
                                <table class="form-table">
                                    <tbody>
                                        <tr>
                                            <th scope="row"><?php _e( 'Sync Type' ); ?></th>
                                            <td>
                                                <fieldset>
                                                    <label><input type="radio" name="wp_api_mus_sync_type" value="auto"<?php echo ( $sync_type == 'auto' ? ' checked="checked"' : '' ); ?> /> <?php _e( 'Auto Sync' ); ?></label><br>
                                                    <label><input type="radio" name="wp_api_mus_sync_type" value="manual"<?php echo ( $sync_type == 'manual' ? ' checked="checked"' : '' ); ?> /> <?php _e( 'Manual Sync' ); ?></label>
                                                </fieldset>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                                <p class="submit">
                                    <input type="submit" name="submit" class="button button-primary" value="<?php _e( 'Save Changes' ); ?>">
                                </p>
                            </form>
                        <?php
                    } else {
                        ?>
                            <div class="notice notice-error is-dismissible">
                                <p><?php _e( 'Please verify purchase code.' ); ?></p>
                            </div>
                        <?php
                    }
                ?>
            </div>
        <?php
    }
}

/*
 * This is a function for licence verification.
 */
if ( ! function_exists( 'wp_api_mus_licence_verification_callback' ) ) {
    function wp_api_mus_licence_verification_callback() {
        
        if ( isset( $_REQUEST['verify'] ) ) {
            if ( isset( $_REQUEST['wp_api_mus_purchase_code'] ) ) {
                update_site_option( 'wp_api_mus_purchase_code', $_REQUEST['wp_api_mus_purchase_code'] );
                
                $data = array(
                    'sku'           => '21608092',
                    'purchase_code' => $_REQUEST['wp_api_mus_purchase_code'],
                    'domain'        => site_url(),
                    'status'        => 'verify',
                    'type'          => 'oi',
                );

                $ch = curl_init();
                curl_setopt( $ch, CURLOPT_URL, 'https://www.obtaininfotech.com/extension/' );
                curl_setopt( $ch, CURLOPT_POST, 1 );
                curl_setopt( $ch, CURLOPT_POSTFIELDS, http_build_query( $data ) );
                curl_setopt( $ch, CURLOPT_RETURNTRANSFER, 1 );
                curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, 0 );
                $json_response = curl_exec( $ch );
                curl_close ($ch);
                
                $response = json_decode( $json_response );
                if ( isset( $response->success ) ) {
                    if ( $response->success ) {
                        update_site_option( 'wp_api_mus_licence', 1 );
                    }
                }
            }
        } else if ( isset( $_REQUEST['unverify'] ) ) {
            if ( isset( $_REQUEST['wp_api_mus_purchase_code'] ) ) {
                $data = array(
                    'sku'           => '21608092',
                    'purchase_code' => $_REQUEST['wp_api_mus_purchase_code'],
                    'domain'        => site_url(),
                    'status'        => 'unverify',
                    'type'          => 'oi',
                );

                $ch = curl_init();
                curl_setopt( $ch, CURLOPT_URL, 'https://www.obtaininfotech.com/extension/' );
                curl_setopt( $ch, CURLOPT_POST, 1 );
                curl_setopt( $ch, CURLOPT_POSTFIELDS, http_build_query( $data ) );
                curl_setopt( $ch, CURLOPT_RETURNTRANSFER, 1 );
                curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, 0 );
                $json_response = curl_exec( $ch );
                curl_close ($ch);

                $response = json_decode( $json_response );
                if ( isset( $response->success ) ) {
                    if ( $response->success ) {
                        update_site_option( 'wp_api_mus_purchase_code', '' );
                        update_site_option( 'wp_api_mus_licence', 0 );
                    }
                }
            }
        }    
        
        $wp_api_mus_purchase_code = get_site_option( 'wp_api_mus_purchase_code' );
        ?>
            <div class="wrap">      
                <h2><?php _e( 'Licence Verification' ); ?></h2>
                <hr>
                <?php
                    if ( isset( $response->success ) ) {
                        if ( $response->success ) {                            
                             ?>
                                <div class="notice notice-success is-dismissible">
                                    <p><?php echo $response->message; ?></p>
                                </div>
                            <?php
                        } else {
                            update_site_option( 'wp_api_mus_licence', 0 );
                            ?>
                                <div class="notice notice-error is-dismissible">
                                    <p><?php echo $response->message; ?></p>
                                </div>
                            <?php
                        }
                    }
                ?>
                <form method="post">
                    <table class="form-table">                    
                        <tbody>
                            <tr>
                                <th scope="row"><?php _e( 'Purchase Code' ); ?></th>
                                <td>
                                    <input name="wp_api_mus_purchase_code" type="text" class="regular-text" value="<?php echo $wp_api_mus_purchase_code; ?>" />
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <p>
                        <input type='submit' class='button-primary' name="verify" value="<?php _e( 'Verify' ); ?>" />
                        <input type='submit' class='button-primary' name="unverify" value="<?php _e( 'Unverify' ); ?>" />
                    </p>
                </form>   
            </div>
        <?php
    }
}