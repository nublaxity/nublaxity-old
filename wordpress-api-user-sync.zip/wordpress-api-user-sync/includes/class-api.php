<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'restricted access' );
}

/*
 * This is a class for WordPress API.
 */
if ( ! class_exists( 'WP_API_MUS' ) ) {
    class WP_API_MUS {

        var $url;
        var $username;
        var $password;
        
        function __construct( $url, $username, $password ) {
                        
            $this->url      = rtrim( $url, '/' ).'/wp-json/wp/v2';
            $this->username = $username;
            $this->password = $password;
        }
        
        function authentication() {
            
            $header = array(
                'Authorization: Basic '.base64_encode( $this->username.':'.$this->password ),
                'Content-Type: application/json',
            );
            
            $ch = curl_init();
            curl_setopt( $ch, CURLOPT_URL, str_replace( 'wp/v2', 'wp_api_mus', $this->url ).'/prefix' );
            curl_setopt( $ch, CURLOPT_HTTPHEADER, $header );
            curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
            curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, false );
            curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, false );
            $json_response = curl_exec( $ch );
            $status = curl_getinfo( $ch, CURLINFO_HTTP_CODE );
            curl_close( $ch );
            $response = json_decode( $json_response );
            
            if ( isset( $response->code ) ) {                
                $log = "errorCode: ".$response->code."\n";
                $log .= "message: ".$response->message."\n";
                $log .= "Date: ".date( 'Y-m-d H:i:s' )."\n\n";                               

                file_put_contents( WP_API_MUS_PLUGIN_PATH.'debug.log', $log, FILE_APPEND );
            }
            
            if ( $status == 0 ) {
                $log = "status: ".$status."\n";
                $log .= "Date: ".date( 'Y-m-d H:i:s' )."\n\n";                               

                file_put_contents( WP_API_MUS_PLUGIN_PATH.'debug.log', $log, FILE_APPEND );
            }
            
            return $response;
        }
        
        function getUsers( $search ) {
            
            $header = array(
                'Authorization: Basic '.base64_encode( $this->username.':'.$this->password ),
                'Content-Type: application/json',
            );
            
            $ch = curl_init();
            curl_setopt( $ch, CURLOPT_URL, $this->url.'/users?search='.$search );
            curl_setopt( $ch, CURLOPT_HTTPHEADER, $header );
            curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
            curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, false );
            curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, false );
            $json_response = curl_exec( $ch );
            $status = curl_getinfo( $ch, CURLINFO_HTTP_CODE );
            curl_close( $ch );
            $response = json_decode( $json_response );
            
            if ( isset( $response->code ) ) {                
                $log = "errorCode: ".$response->code."\n";
                $log .= "message: ".$response->message."\n";
                $log .= "Date: ".date( 'Y-m-d H:i:s' )."\n\n";                               

                file_put_contents( WP_API_MUS_PLUGIN_PATH.'debug.log', $log, FILE_APPEND );
            }
            
            if ( $status == 0 ) {
                $log = "status: ".$status."\n";
                $log .= "Date: ".date( 'Y-m-d H:i:s' )."\n\n";                               

                file_put_contents( WP_API_MUS_PLUGIN_PATH.'debug.log', $log, FILE_APPEND );
            }
            
            return $response;
        }
        
        function addUser( $data ) {
            
            $data = json_encode( $data );
            $header = array(
                'Authorization: Basic '.base64_encode( $this->username.':'.$this->password ),
                'Content-Type: application/json',
            );
            
            $ch = curl_init();
            curl_setopt( $ch, CURLOPT_URL, $this->url.'/users' );
            curl_setopt( $ch, CURLOPT_HTTPHEADER, $header );
            curl_setopt( $ch, CURLOPT_POST, true );
            curl_setopt( $ch, CURLOPT_POSTFIELDS, $data );
            curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
            curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, false );
            curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, false );
            $json_response = curl_exec( $ch );
            $status = curl_getinfo( $ch, CURLINFO_HTTP_CODE );
            curl_close( $ch );
            $response = json_decode( $json_response );
            
            if ( isset( $response->code ) ) {                
                $log = "errorCode: ".$response->code."\n";
                $log .= "message: ".$response->message."\n";
                $log .= "Date: ".date( 'Y-m-d H:i:s' )."\n\n";                               

                file_put_contents( WP_API_MUS_PLUGIN_PATH.'debug.log', $log, FILE_APPEND );
            }
            
            if ( $status == 0 ) {
                $log = "status: ".$status."\n";
                $log .= "Date: ".date( 'Y-m-d H:i:s' )."\n\n";                               

                file_put_contents( WP_API_MUS_PLUGIN_PATH.'debug.log', $log, FILE_APPEND );
            }
            
            return $response;
        }
        
        function updateUser( $data, $user_id ) {
            
            $data = json_encode( $data );
            $header = array(
                'Authorization: Basic '.base64_encode( $this->username.':'.$this->password ),
                'Content-Type: application/json',
            );
            
            $ch = curl_init();
            curl_setopt( $ch, CURLOPT_URL, $this->url.'/users/'.$user_id );
            curl_setopt( $ch, CURLOPT_HTTPHEADER, $header );
            curl_setopt( $ch, CURLOPT_POST, true );
            curl_setopt( $ch, CURLOPT_POSTFIELDS, $data );
            curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
            curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, false );
            curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, false );
            $json_response = curl_exec( $ch );
            $status = curl_getinfo( $ch, CURLINFO_HTTP_CODE );
            curl_close( $ch );
            $response = json_decode( $json_response );
            
            if ( isset( $response->code ) ) {                
                $log = "errorCode: ".$response->code."\n";
                $log .= "message: ".$response->message."\n";
                $log .= "Date: ".date( 'Y-m-d H:i:s' )."\n\n";                               

                file_put_contents( WP_API_MUS_PLUGIN_PATH.'debug.log', $log, FILE_APPEND );
            }
            
            if ( $status == 0 ) {
                $log = "status: ".$status."\n";
                $log .= "Date: ".date( 'Y-m-d H:i:s' )."\n\n";                               

                file_put_contents( WP_API_MUS_PLUGIN_PATH.'debug.log', $log, FILE_APPEND );
            }
            
            return $response;
        }
    }
}