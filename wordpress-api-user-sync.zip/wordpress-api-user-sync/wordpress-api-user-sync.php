<?php
/*
Plugin Name: WordPress API Multiple Sites User Sync
Description: This is a WordPress API Multiple Sites User Sync plugin.
Version: 1.0.0
Author: Obtain Infotech
Author URI: https://www.obtaininfotech.com/
License: GPL2
*/

if ( ! defined( 'ABSPATH' ) ) {
    exit( 'restricted access' );
}

/*
 * This is a constant variable for plugin path.
 */
define( 'WP_API_MUS_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );

/*
 * This is a file for includes core functionality.
 */
include_once WP_API_MUS_PLUGIN_PATH . 'includes/includes.php';

/*
 * This is a function that run during active plugin
 */
if ( ! function_exists( 'wp_api_mus_activation' ) ) {
    register_activation_hook( __FILE__, 'wp_api_mus_activation' );
    function wp_api_mus_activation() {
        
        $sync_type = get_option( 'wp_api_mus_sync_type' );
        if ( ! $sync_type ) {
            update_option( 'wp_api_mus_sync_type', 'auto' );
        }
    }
}