<?php
if ( !defined( 'ABSPATH' ) ) die( 'No direct access.' );
/**
 * Controls the plugins tab and handles the saving of its options.
 *
 * @package WordPress
 * @since 5.0.0
 */
class MPSUM_Admin_Plugins {
	/**
     * Holds the slug to the admin panel page
     *
     * @since 5.0.0
     * @access private
     * @var string $slug
     */
	private $slug = '';

	/**
     * Holds the tab name
     *
     * @since 5.0.0
     * @access private
     * @var string $tab
     */
	private $tab = 'plugins';

	/**
     * Class constructor.
     *
     * Initialize the class
     *
     * @since 5.0.0
     * @access public
     *
     * @param string $slug Slug to the admin panel page
     */
	public function __construct( $slug = '' ) {
		$this->slug = $slug;

		// Admin Tab Actions
		add_action( 'mpsum_admin_tab_plugins', array( $this, 'tab_output' ) );
		add_filter( 'mpsum_plugin_action_links', array( $this, 'plugin_action_links' ), 11, 2 );
	}

	/**
     * Determine whether the plugins can be updated or not.
     *
     * Determine whether the plugins can be updated or not.
     *
     * @since 5.0.0
     * @access private
     *
     * @return bool True if the plugins can be updated, false if not.
     */
	private function can_update() {
		$core_options = MPSUM_Updates_Manager::get_options( 'core' );
		if ( isset( $core_options[ 'all_updates' ] ) && 'off' == $core_options[ 'all_updates' ] ) {
			return false;
		}
		if ( isset( $core_options[ 'plugin_updates' ] ) && 'off' == $core_options[ 'plugin_updates' ] ) {
			return false;
		}
		return true;
	}

	/**
	 * Outputs the plugin action links beneath each plugin row.
	 *
	 * Outputs the plugin action links beneath each plugin row.
	 *
	 * @since 5.0.0
	 * @access public
	 * @see __construct
	 * @internal uses mpsum_plugin_action_links filter
	 *
	 * @param array  $settings Array of settings to output.
	 * @param string $plugin   The relative plugin path.
	 *
	 * @return array Array of settings to output.
	 */
	public function plugin_action_links( $settings, $plugin ) {
		return $settings;
	}

	/**
	 * Output the HTML interface for the plugins tab.
	 *
	 * Output the HTML interface for the plugins tab.
	 *
	 * @since 5.0.0
	 * @access public
	 * @see __construct
	 * @internal Uses the mpsum_admin_tab_plugins action
	 */
	public function tab_output() {
		?>
        <form action="<?php echo esc_url( add_query_arg( array() ) ); ?>" method="post">
	    <?php
		$plugin_status = isset( $_GET[ 'plugin_status' ] ) ? $_GET[ 'plugin_status' ] : false;
		if ( false !== $plugin_status ) {
			printf( '<input type="hidden" name="plugin_status" value="%s" />', esc_attr( $plugin_status ) );
		}
		?>
        <h3><?php esc_html_e( 'Plugin Update Options', 'stops-core-theme-and-plugin-updates' ); ?></h3>
        <?php
	    $core_options = MPSUM_Updates_Manager::get_options( 'core' );
	    if ( false === $this->can_update() ) {
			printf( '<div class="error"><p><strong>%s</strong></p></div>', esc_html__( 'All plugin updates have been disabled.', 'stops-core-theme-and-plugin-updates' ) );
		}
        printf( '<div id="eum-save-settings-warning" class="warning"><p>%s</p></div>', esc_html__( 'Remember to save your settings', 'stops-core-theme-and-plugin-updates') );
		$plugin_table = new MPSUM_Plugins_List_Table( $args = array( 'screen' => $this->slug, 'tab' => $this->tab ) );
		$plugin_table->prepare_items();
        $plugin_table->views();
		$plugin_table->display();
		submit_button('Save','primary','submit', true, array('id' => 'eum-save-settings'));
		?>
        </form>
    <?php
	} //end tab_output_plugins
}
