<?php
/*
Plugin Name: Social Share myCRED Integration by Heateor
Plugin URI: https://www.heateor.com
Description: Reward myCRED points to website users for sharing content at social networks
Version: 1.3.9
Author: Team Heateor
Author URI: https://www.heateor.com
License: GPL2+
*/
defined( 'ABSPATH' ) or die( "Cheating........Uh!!" );
define( 'HEATEOR_SOCIAL_SHARE_MYCRED_INTEGRATION_VERSION', '1.3.9' );
define( 'HEATEOR_SOCIAL_SHARE_MYCRED_INTEGRATION_SLUG', 'social-share-heateor-myCRED-integration' );

$heateor_ssmi_options = get_option( 'heateor_ssmi' );
$heateor_ssmi_license_options = get_option( 'heateor_ssmi_license' );

if ( is_admin() && isset( $heateor_ssmi_license_options['license_key'] ) && $heateor_ssmi_license_options['license_key'] != '' ) {
	require 'library/plugin-update-checker/plugin-update-checker.php';
	$htMyUpdateChecker = PucFactory::buildUpdateChecker(
	    'https://www.heateor.com/api/license-manager/v1/info?l=' . $heateor_ssmi_license_options['license_key'] . '&w=' . urlencode( str_replace( array( 'http://', 'https://' ), '', site_url() ) ),
	    __FILE__,
	    strtolower( HEATEOR_SOCIAL_SHARE_MYCRED_INTEGRATION_SLUG )
	);
}

/**
 * Update options, version on basis of version comparison
 */
function heateor_ssmi_update_db_check() {
	if ( get_option( 'heateor_ssmi_version' ) != HEATEOR_SOCIAL_SHARE_MYCRED_INTEGRATION_VERSION ) {
		update_option( 'heateor_ssmi_version', HEATEOR_SOCIAL_SHARE_MYCRED_INTEGRATION_VERSION );
	}
}
add_action( 'plugins_loaded', 'heateor_ssmi_update_db_check' );

/**
 * Create plugin menu in admin.
 */	
function heateor_ssmi_create_admin_menu() {
	$options_page = add_menu_page( 'Heateor - Social Share myCRED Integration', '<b>Sharing - myCRED Integration</b>', 'manage_options', 'heateor-ssmi', 'heateor_ssmi_option_page', plugins_url( 'images/logo.png', __FILE__ ) );
	$license_page = add_submenu_page( 'heateor-ssmi', 'License Settings', 'License Settings', 'manage_options', 'heateor-ssmi-license-settings', 'heateor_ssmi_license_settings_page' );
	add_action( 'admin_print_scripts-' . $options_page, 'heateor_ssmi_admin_scripts' );
	add_action( 'admin_print_scripts-' . $options_page, 'heateor_ssmi_admin_style' );
	add_action( 'admin_print_scripts-' . $options_page, 'heateor_ssmi_fb_sdk_script' );
	add_action( 'admin_print_scripts-' . $license_page, 'heateor_ssmi_admin_scripts' );
	add_action( 'admin_print_scripts-' . $license_page, 'heateor_ssmi_fb_sdk_script' );
	add_action( 'admin_print_styles-' . $license_page, 'heateor_ssmi_admin_style' );
}
add_action( 'admin_menu', 'heateor_ssmi_create_admin_menu' );

/**
 * Include javascript files in admin.
 */	
function heateor_ssmi_admin_scripts() {
	?>
	<script>var heateorSsmiWebsiteUrl = '<?php echo site_url() ?>', heateorSsmiHelpBubbleTitle = "<?php echo __( 'Click to show help', 'heateor-ssmi-text' ) ?>", heateorSsmiHelpBubbleCollapseTitle = "<?php echo __( 'Click to hide help', 'heateor-ssmi-text' ) ?>"; </script>
	<?php
	wp_enqueue_script( 'heateor_ssmi_admin_scripts', plugins_url( 'js/admin/admin.js', __FILE__ ), array( 'jquery' ), HEATEOR_SOCIAL_SHARE_MYCRED_INTEGRATION_VERSION );
}

/**
 * Include CSS files in admin.
 */	
function heateor_ssmi_admin_style() {
	wp_enqueue_style( 'heateor_ssmi_admin_style', plugins_url( 'css/admin.css', __FILE__ ), false, HEATEOR_SOCIAL_SHARE_MYCRED_INTEGRATION_VERSION );
}

/**
 * Include Javascript SDK in admin.
 */	
function heateor_ssmi_fb_sdk_script() {
	wp_enqueue_script( 'heateor_ssmi_fb_sdk_script', plugins_url( 'js/admin/fb_sdk.js', __FILE__ ), false, HEATEOR_SOCIAL_SHARE_MYCRED_INTEGRATION_VERSION );
}

/**
 * Register plugin options
 */	
function heateor_ssmi_plugin_settings_fields() {
	register_setting( 'heateor_ssmi_options', 'heateor_ssmi', 'heateor_ssmi_validate_options' );
	register_setting( 'heateor_ssmi_license_options', 'heateor_ssmi_license', 'heateor_ssmi_validate_options' );
}
add_action( 'admin_init', 'heateor_ssmi_plugin_settings_fields' );

/**
 * Display notification message when plugin options are saved
 */
function heateor_ssmi_settings_saved_notification() {
	if ( isset( $_GET['settings-updated'] ) && $_GET['settings-updated'] == 'true' ) {
		return '<div id="setting-error-settings_updated" class="updated settings-error notice is-dismissible below-h2"> 
<p><strong>' . __( 'Settings saved', 'heateor-ssmi-text' ) . '</strong></p><button type="button" class="notice-dismiss"><span class="screen-reader-text">' . __( 'Dismiss this notice', 'heateor-ssmi-text' ) . '</span></button></div>';
	}
}

/**
 * License Options page
 */
function heateor_ssmi_license_settings_page() {
	global $heateor_ssmi_license_options;
	echo heateor_ssmi_settings_saved_notification();
	require 'admin/license-options.php';
}

/**
 * Plugin options page.
 */	
function heateor_ssmi_option_page() {
	global $heateor_ssmi_options;
	echo heateor_ssmi_settings_saved_notification();
	require 'admin/plugin-options.php';
}

/** 
 * Validate plugin options
 */ 
function heateor_ssmi_validate_options( $options ) {
	foreach ( $options as $k => $v ) {
		if ( is_string( $v ) ) {
			$options[$k] = trim( esc_attr( $v ) );
		}
	}
	return $options;
}

/**
 * Save default options when plugin is activated
 */
function heateor_ssmi_default_options() {
	// plugin version
	add_option( 'heateor_ssmi_version', HEATEOR_SOCIAL_SHARE_MYCRED_INTEGRATION_VERSION );
}
register_activation_hook( __FILE__, 'heateor_ssmi_default_options' );

/**
 * Set flag in database if notification has been read
 */
function heateor_ssmi_notification_read() {
	update_option( 'heateor_ssmi_notification_read', '1' );
	die;
}
add_action( 'wp_ajax_heateor_ssmi_notification_read', 'heateor_ssmi_notification_read' );

/**
 * Show notifications related to add-on license
 */
function heateor_ssmi_license_notification() {
	if ( ( is_multisite() && is_main_site() && current_user_can( 'manage_options' ) ) || ( ! is_multisite() && current_user_can( 'manage_options' ) ) ) {
		if ( ! get_option( 'heateor_ssmi_notification_read' ) ) {
			?>
			<script type="text/javascript">
			function heateorSsmiNotificationRead(){
				jQuery.ajax({
					type: 'GET',
					url: '<?php echo get_admin_url() ?>admin-ajax.php',
					data: {
						action: 'heateor_ssmi_notification_read'
					},
					success: function(data, textStatus, XMLHttpRequest){
						jQuery('#heateor_ssmi_gp_notification').fadeOut();
					}
				});
			}
			</script>
			<div id="heateor_ssmi_gp_notification" class="error notice">
				<h3>Social Sharing - myCRED Integration</h3>
				<p><?php _e( '"Points for Google share" option is "Points for Googleplus share" now in "Points for Social Sharing" hook at "myCRED > Hooks" page. You need to save the value in it (and its Log template) again if it was different from default value (1.00)', 'heateor-ssmi-text' ) ?><input type="button" onclick="heateorSsmiNotificationRead()" style="margin-left: 8px" class="button button-primary" value="<?php _e( 'Okay', 'heateor-ssmi-text' ) ?>" /></p>
			</div>
			<?php
		}
		global $heateor_ssmi_license_options;
		if ( ( ! isset( $heateor_ssmi_license_options['license_key'] ) || $heateor_ssmi_license_options['license_key'] == '' ) ) {
			?>
			<div class="error">
				<h3>Social Sharing - myCRED Integration</h3>
				<p><?php _e( 'Save license key at <strong>Sharing - myCRED Integration > License Settings</strong> page to enable plugin updates', 'heateor-ssmi-text' ) ?><a style="margin-left: 8px" href="<?php echo admin_url() . 'admin.php?page=heateor-ssmi-license-settings' ?>"><input type="button" class="button button-primary" value="<?php _e( 'Let\'s do it', 'heateor-ssmi-text' ) ?>" /></a></p>
			</div>
			<?php
		}

		$heateor_ssmi_last_update_check = get_option( 'external_updates-' . HEATEOR_SOCIAL_SHARE_MYCRED_INTEGRATION_SLUG );
		if ( $heateor_ssmi_last_update_check && ! empty( $heateor_ssmi_last_update_check->update->upgrade_notice ) ) {
			?>
			<div class="error">
				<h3>Social Share - myCRED Integration</h3>
				<p><?php echo $heateor_ssmi_last_update_check->update->upgrade_notice ?></p>
			</div>
			<?php
		}
	}
}
add_action( 'admin_notices', 'heateor_ssmi_license_notification' );

/**
 * Register myCRED Hook
 */
function heateor_ssmi_custom_hook( $installed ) {
	$installed['heateor_sharing'] = array(
		'title'       => __( 'Points for Social Sharing', 'heateor-ssmi-text' ),
		'description' => __( 'Awards %_plural% for Social Sharing', 'heateor-ssmi-text' ),
		'callback'    => array( 'Heateor_Social_Share_myCRED' )
	);
	return $installed;
}
add_filter( 'mycred_setup_hooks', 'heateor_ssmi_custom_hook' );

if ( ! class_exists( 'Heateor_Social_Share_myCRED' ) && class_exists( 'myCRED_Hook' ) ) {
	class Heateor_Social_Share_myCRED extends myCRED_Hook {
		private $sharingOptions = array();
		private $counterOptions = array();

		/**
		 * Construct
		 */
		public function __construct( $hook_prefs ) {

			global $theChampSharingOptions, $theChampCounterOptions;

			if ( isset( $theChampSharingOptions) && isset( $theChampSharingOptions['enable'] ) ) {
				$this->sharingOptions = $theChampSharingOptions;
				$this->counterOptions = $theChampCounterOptions;
			} elseif ( defined( 'HEATEOR_SSS_VERSION' ) ) {
				$this->sharingOptions = get_option( 'heateor_sss' );
			}

			$horizontal_sharing_networks = isset( $this->sharingOptions['horizontal_re_providers'] ) ? $this->sharingOptions['horizontal_re_providers'] : array();
			$vertical_sharing_networks = isset( $this->sharingOptions['vertical_re_providers'] ) ? $this->sharingOptions['vertical_re_providers'] : array();
			$share_like_buttons = array( 'facebook_share', 'facebook_like', 'facebook_recommend', 'twitter_tweet', 'google_plusone', 'google_plus_share', 'linkedin_share', 'pinterest_pin', 'buffer_share', 'xing_share', 'yummly_share', 'reddit_badge', 'stumbleupon_badge' );
			$supported_sharing_networks = array_diff( array_unique( array_merge( $horizontal_sharing_networks, $vertical_sharing_networks ) ), $share_like_buttons );

			// social sharing networks
			$defaults = array();
			foreach ( $supported_sharing_networks as $network ) {
				$network = ucfirst( $network );
				$defaults[$network . '_creds'] = 1;
				$defaults[$network . '_log'] = '%plural% for '. str_replace( '_', ' ', $network ) .' share for url: %url%';
			}
			$defaults['Other_creds'] = 1;
			$defaults['Other_log'] = '%plural% for sharing via other networks (More icon popup) for url: %url%';
			$defaults['Facebook_like_recommend_creds'] = 1;
			$defaults['Facebook_like_recommend_log'] = '%plural% for Facebook like/recommend for url: %url%';
			$defaults['Twitter_tweet_creds'] = 1;
			$defaults['Twitter_tweet_log'] = '%plural% for Twitter Tweet for url: %url%';
			$defaults['Google_plusone_creds'] = 1;
			$defaults['Google_plusone_log'] = '%plural% for Google +1 for url: %url%';
			$defaults['no_of_times_per_webpage'] = '';
			$defaults['limit_count'] = 1;
			$defaults['limit'] = 'hour';
			$defaults['limit_pages'] = '';

			parent::__construct( array(
				'id'       => 'heateor_sharing',
				'defaults' => $defaults
			), $hook_prefs );
		}

		/**
		 * Hook into WordPress
		 */
		public function run() {
			add_action( 'init', array( $this, 'init' ) );
			add_action( 'wp_ajax_heateor_ssmi_share_click', array( $this, 'share_click' ) );
		}

		/**
		 * Load scripts at front-end
		 */
		public function frontend_scripts() {
			if ( is_user_logged_in() ) {
				$in_footer = false;
				$amp_enabled = false;
				if ( defined( 'HEATEOR_SSS_VERSION' ) ) {
					$options = get_option( 'heateor_sss' );
					if ( isset( $options['amp_enable'] ) ) {
						$amp_enabled = true;
					} else {
						$in_footer = isset( $options['footer_script'] ) ? true : false;
					}
				} elseif ( defined( 'THE_CHAMP_SS_VERSION' ) ) {
					if ( version_compare( THE_CHAMP_SS_VERSION, '6.9' ) ) {
						global $theChampGeneralOptions;
						$in_footer = isset( $theChampGeneralOptions['footer_script'] ) ? true : false;
					} else {
						global $theChampLoginOptions;
						$in_footer = isset( $theChampLoginOptions['footer_script'] ) ? true : false;
					}
				}
				if ( $amp_enabled ) {
					add_action( 'amp_post_template_head', array( $this, 'frontend_amp_scripts' ) );
				}
				?>
				<script type="text/javascript">var heateorSsmiAjaxUrl = '<?php echo get_admin_url() ?>admin-ajax.php';</script>
				<?php
				wp_enqueue_script( 'heateor_ssmi_frontend_scripts', plugins_url( 'js/front/front.js', __FILE__ ), array( 'jquery' ), HEATEOR_SOCIAL_SHARE_MYCRED_INTEGRATION_VERSION, $in_footer );
			}
		}

		/**
		 * Javascript to make add-on work on AMP pages
		 */
		public function frontend_amp_scripts() {
			?>
			<script type="text/javascript">
			var heateorSsmiAjaxUrl = '<?php echo get_admin_url() ?>admin-ajax.php';
			function heateorSsmiMycredPoints(e, t, r, i){
			    jQuery.ajax({
			        type: "GET",
			        dataType: "json",
			        url: heateorSsmiAjaxUrl,
			        data: {
			            action: "heateor_ssmi_share_click",
			            provider: e,
			            log_provider: "undefined" != typeof t ? t : "",
			            url: r,
			            deduct: "undefined" != typeof i ? i : ""
			        },
			        success: function() {}
			    })
			}

			function heateorSsmiGpCallback(e){
			    "on" == e.state ? heateorSsmiMycredPoints("Google_plusone", "", e.href ? e.href : "") : "off" == e.state && heateorSsmiMycredPoints("Google_plusone", "", e.href ? e.href : "", "Minus point(s) for undoing Google +1")
			}
			jQuery(function(){
			    jQuery(".the_champ_sharing_container i, .heateor_sss_sharing_container i").click(function() {
			        var e = jQuery(this).attr("alt");
			        "More" != e && "Total Shares" != e && ("Google Plus" == e ? e = "Google" : "Float it" == e && (e = "Floatit"), heateorSsmiMycredPoints(e, "", jQuery(this).parents(".the_champ_sharing_container").length ? jQuery(this).parents(".the_champ_sharing_container").attr("super-socializer-data-href") : jQuery(this).parents(".heateor_sss_sharing_container").attr("heateor-sss-data-href") ))
			    }), jQuery(".theChampMoreBackground, .heateorSssMoreBackground").click(function() {
			        jQuery("#the_champ_sharing_more_content li, #heateor_sss_sharing_more_content li").find("a").click(function() {
			            heateorSsmiMycredPoints("Other", jQuery(this).find("i").attr("title"), jQuery(this).parents(".the_champ_sharing_container").length ? jQuery(this).parents(".the_champ_sharing_container").attr("super-socializer-data-href") : jQuery(this).parents(".heateor_sss_sharing_container").attr("heateor-sss-data-href") )
			        })
			    }), jQuery("#twitter-wjs").load(function() {
			        twttr.ready(function(e) {
			            e.events.bind("tweet", function(e) {
			                "tweet" == e.type && heateorSsmiMycredPoints("Twitter_tweet", "", jQuery(e.target).parent().attr("heateor-ss-data-href") ? jQuery(e.target).parent().attr("heateor-ss-data-href") : jQuery(e.target).parent().attr("heateor-sss-data-href") )
			            })
			        })
			    })
			});
			</script>
			<?php
		}

		/**
		 * Load scripts on init
		 */
		public function init() {
			add_action( 'wp_enqueue_scripts', array( $this, 'frontend_scripts' ) );
		}

		/**
		 * On share icon click
		 */
		public function share_click() {
			global $user_ID;

			// Check if user is excluded
			if ( $this->core->exclude_user( $user_ID ) ) return;
			
			$provider = isset( $_GET['provider'] ) && trim( esc_attr( $_GET['provider'] ) ) != '' ? trim( esc_attr( $_GET['provider'] ) ) : '';
			$log_provider = isset( $_GET['log_provider'] ) && trim( esc_attr( $_GET['log_provider'] ) ) != '' ? trim( esc_attr( $_GET['log_provider'] ) ) : '';
			$url = isset( $_GET['url'] ) && trim( esc_url( $_GET['url'] ) ) != '' ? trim( esc_url( $_GET['url'] ) ) : '';
			$deduct = isset( $_GET['deduct'] ) && trim( esc_attr( $_GET['deduct'] ) ) != '' ? trim( esc_attr( $_GET['deduct'] ) ) . ( $url != '' ? ' for url: ' . $url : '' ) : '';
			if ( $provider && $user_ID ) {
				$log_entry = str_replace( array( '%sharing_network%', '%url%' ), array( $log_provider, $url ), $this->prefs[ucfirst( str_replace( ' ', '_', $provider ) ) . '_log'] );
				if ( $this->prefs['no_of_times_per_webpage'] ) {
					global $wpdb;
					$prev_entries = $wpdb -> get_var( $wpdb -> prepare( "SELECT count(user_id) FROM " . $wpdb->prefix . "myCRED_log WHERE ref = 'heateor_sharing' and user_id = %d and entry LIKE '%%%s%%'", $user_ID, $url ) );
					if ( $prev_entries < intval( $this->prefs['no_of_times_per_webpage'] ) ) {
						$this -> log_entry( $provider, $log_entry, $deduct );
					}
				} elseif ( $this->prefs['limit_count'] == '' ) {
					$this -> log_entry( $provider, $log_entry, $deduct );
				} elseif ( ! isset( $this->prefs['limit_pages'] ) || $this->prefs['limit_pages'] == '' ) {
					global $wpdb;
					$prev_entry_time = $wpdb -> get_var( $wpdb -> prepare( "SELECT time FROM " . $wpdb->prefix . "myCRED_log WHERE ref = 'heateor_sharing' and user_id = %d and entry = %s ORDER BY id DESC LIMIT 1", $user_ID, $deduct ? $deduct : $log_entry ) );
					if ( $prev_entry_time ) {
						$limit = $this->prefs['limit'];
						$multiplier = 1;
						switch ( $limit ) {
							case 'minute':
								$multiplier = 60;
								break;
							
							case 'hour':
								$multiplier = 3600;
								break;

							case 'day':
								$multiplier = 3600*24;
								break;

							default:
								$multiplier = 1;
								break;
						}
						if ( $prev_entry_time + ( $multiplier*$this->prefs['limit_count'] ) < time() ) {
							$this -> log_entry( $provider, $log_entry, $deduct );
						}
					} else {
						$this -> log_entry( $provider, $log_entry, $deduct );
					}
				} else {
					global $wpdb;
					$last_entry_time = $wpdb -> get_var( $wpdb -> prepare( "SELECT time FROM " . $wpdb->prefix . "myCRED_log WHERE ref = 'heateor_sharing' and user_id = %d and " . ( $deduct ? "creds < 0" : "creds > 0" ) . " and data = %s ORDER BY id DESC LIMIT 1", $user_ID, $provider ) );
					if ( $last_entry_time ) {
						$limit = $this->prefs['limit'];
						$multiplier = 1;
						switch ( $limit) {
							case 'minute':
								$multiplier = 60;
								break;
							
							case 'hour':
								$multiplier = 3600;
								break;

							case 'day':
								$multiplier = 3600*24;
								break;

							default:
								$multiplier = 1;
								break;
						}
						$prev_entry_time = $wpdb -> get_results( $wpdb -> prepare( "SELECT time, entry FROM " . $wpdb->prefix . "myCRED_log WHERE ref = 'heateor_sharing' and user_id = %d and " . ( $deduct ? "creds < 0" : "creds > 0" ) . " and data = %s and time >= %d ORDER BY id DESC LIMIT %d", $user_ID, $provider, $last_entry_time - $multiplier*$this->prefs['limit_count'], $this->prefs['limit_pages'] ) );
						if ( $prev_entry_time ) {
							if ( time() - $prev_entry_time[0]->time > $multiplier*$this->prefs['limit_count'] ) {
								$this -> log_entry( $provider, $log_entry, $deduct );
							} elseif ( count( $prev_entry_time ) < $this->prefs['limit_pages'] ) {
								$loop_count = 0;
								foreach ( $prev_entry_time as $time ) {
									if ( $log_entry == $time->entry ) {
										$loop_count++;
										break;
									}
								}
								if ( $loop_count == 0 ) { 
									$this -> log_entry( $provider, $log_entry, $deduct );
								}
							}
						} else {
							$this -> log_entry( $provider, $log_entry, $deduct );
						}
					} else {
						$this -> log_entry( $provider, $log_entry, $deduct );
					}					
				}
			}
			die;
		}

		/**
		 * Create log entry
		 */
		public function log_entry( $provider, $log_entry, $deduct ) {
			if ( $this->prefs[ucfirst( str_replace( ' ', '_', $provider) ) . '_creds'] ) {
				global $user_ID;
				$this->core->add_creds(
					'heateor_sharing',
					$user_ID,
					$deduct ? -$this->prefs[ucfirst( str_replace( ' ', '_', $provider ) ) . '_creds'] : $this->prefs[ucfirst( str_replace( ' ', '_', $provider) ) . '_creds'],
					$deduct ? $deduct : $log_entry,
					'',
					$provider
				);
			}
		}

		/**
		 * Add Settings
		 */
		public function preferences() {
			// Our settings are available under $this->prefs
			$prefs = $this->prefs;

			if ( $this->sharingOptions ) {
				$horizontal_sharing_networks = isset( $this->sharingOptions['horizontal_re_providers'] ) ? $this->sharingOptions['horizontal_re_providers'] : array();
				$vertical_sharing_networks = isset( $this->sharingOptions['vertical_re_providers'] ) ? $this->sharingOptions['vertical_re_providers'] : array();
				$horizontal_like_buttons = isset( $this->counterOptions['horizontal_providers'] ) ? array_diff( $this->counterOptions['horizontal_providers'], array( 'googleplus_share', 'linkedin_share', 'pinterest_pin_it', 'xing', 'reddit', 'stumbleupon_badge', 'yummly', 'buffer' ) ) : array();
				$vertical_like_buttons = isset( $this->counterOptions['vertical_providers'] ) ? array_diff( $this->counterOptions['vertical_providers'], array( 'googleplus_share', 'linkedin_share', 'pinterest_pin_it', 'xing', 'reddit', 'stumbleupon_badge', 'yummly', 'buffer' ) ) : array();
				$share_like_buttons = array( 'facebook_share', 'facebook_like', 'facebook_recommend', 'twitter_tweet', 'google_plusone', 'google_plus_share', 'linkedin_share', 'pinterest_pin', 'buffer_share', 'xing_share', 'yummly_share', 'reddit_badge', 'stumbleupon_badge' );
				$sharing_networks = array_diff( array_unique( array_merge( $horizontal_sharing_networks, $vertical_sharing_networks ) ), $share_like_buttons );
				$like_buttons = array_unique( array_merge( $horizontal_like_buttons, $vertical_like_buttons, array_intersect( array( 'facebook_like', 'facebook_recommend', 'twitter_tweet' ), array_unique( array_merge( $horizontal_sharing_networks, $vertical_sharing_networks ) ) ) ) );
				if ( $like_buttons ) {
					foreach ( $like_buttons as $k => $v ) {
						if ( $v == 'facebook_like' || $v == 'facebook_recommend' ) {
							$like_buttons[$k] = 'facebook_like_recommend';
						}
					}
				}
				$like_buttons = array_unique( $like_buttons );
				if ( $sharing_networks ) {
					?>
					<h2><?php _e( 'Share Buttons', 'heateor-ssmi-text' ); ?></h2>
					<hr/>
					<?php
					foreach ( $sharing_networks as $network ) {
						$network = ucfirst( $network );
						?>
						<!-- First we set the amount -->
						<label class="subheader"><?php echo $this->core->plural() . ' for ' . str_replace( '_', '', $network ) . ' share'; ?></label>
						<ol>
							<li>
								<div class="h2"><input type="text" name="<?php echo $this->field_name( $network . '_creds' ); ?>" id="<?php echo $this->field_id( $network . '_creds' ); ?>" value="<?php echo $this->core->format_number( isset( $prefs[$network . '_creds'] ) ? $prefs[$network . '_creds'] : 1 ); ?>" size="8" /></div>
							</li>
						</ol>
						<!-- Then the log template -->
						<label class="subheader"><?php _e( 'Log template', 'mycred' ); ?></label>
						<ol>
							<li>
								<div class="h2"><input type="text" name="<?php echo $this->field_name( $network . '_log' ); ?>" id="<?php echo $this->field_id( $network . '_log' ); ?>" value="<?php echo isset( $prefs[$network . '_log'] ) ? $prefs[$network . '_log'] : '%plural% for ' . str_replace( '_', '', $network ) . ' share'; ?>" class="long" /></div>
							</li>
						</ol>
						<?php
					}
				} else {
					echo '<h3 style="color:red">';
					_e( 'Enable sharing networks to see the options', 'heateor-ssmi-text' );
					echo '</h3>';
				}

				if ( isset( $this->sharingOptions['horizontal_more'] ) || isset( $this->sharingOptions['vertical_more'] ) ) {
					?>
					<label class="subheader"><?php echo $this->core->plural() . ' for sharing via other networks ("more" icon popup)' ; ?></label>
					<ol>
						<li>
							<div class="h2"><input type="text" name="<?php echo $this->field_name( 'Other_creds' ); ?>" id="<?php echo $this->field_id( 'Other_creds' ); ?>" value="<?php echo $this->core->format_number( isset( $prefs['Other_creds'] ) ? $prefs['Other_creds'] : 1 ); ?>" size="8" /></div>
						</li>
					</ol>
					<!-- Then the log template -->
					<label class="subheader"><?php _e( 'Log template', 'mycred' ); ?></label>
					<ol>
						<li>
							<div class="h2"><input type="text" name="<?php echo $this->field_name( 'Other_log' ); ?>" id="<?php echo $this->field_id( 'Other_log' ); ?>" value="<?php echo isset( $prefs['Other_log'] ) ? $prefs['Other_log'] : '%plural% for sharing via %sharing_network% (More icon popup)'; ?>" class="long" /></div>
						</li>
					</ol>
					<?php
				}

				if ( $like_buttons ) {
					?>
					<h2><?php _e( 'Like Buttons', 'heateor-ssmi-text' ); ?></h2>
					<hr/>
					<?php
					foreach ( $like_buttons as $network ) {
						$network = ucfirst( $network );
						?>
						<!-- First we set the amount -->
						<label class="subheader"><?php echo $this->core->plural() . ' for ' . str_replace( '_', ' ', $network ); ?></label>
						<ol>
							<li>
								<div class="h2"><input type="text" name="<?php echo $this->field_name( $network . '_creds' ); ?>" id="<?php echo $this->field_id( $network . '_creds' ); ?>" value="<?php echo $this->core->format_number( isset( $prefs[$network . '_creds'] ) ? $prefs[$network . '_creds'] : 1 ); ?>" size="8" /></div>
							</li>
						</ol>
						<!-- Then the log template -->
						<label class="subheader"><?php _e( 'Log template', 'mycred' ); ?></label>
						<ol>
							<li>
								<div class="h2"><input type="text" name="<?php echo $this->field_name( $network . '_log' ); ?>" id="<?php echo $this->field_id( $network . '_log' ); ?>" value="<?php echo isset( $prefs[$network . '_log'] ) ? $prefs[$network . '_log'] : '%plural% for ' . str_replace( '_', ' ', $network ); ?>" class="long" /></div>
							</li>
						</ol>
						<?php
					}
				}

				if ( $sharing_networks || $like_buttons ) {
					?>
					<h2><?php _e( 'Limit', 'heateor-ssmi-text' ); ?></h2>
					<hr/>
					<label class="subheader"><?php _e( 'Number of times points can be earned by sharing a particular webpage by a user (irrespective of the social network used to share the webpage). Sharing that webpage after that will not grant that user any points', 'heateor-ssmi-text' ); ?></label>
					<div style="clear:both">
						<?php _e( 'For example, if you save 2, a user can earn points for sharing a particular webpage twice irrespective of the social network they use. That user will not get any points for sharing that webpage after that. If you leave it empty, users will get points each time they share a different webpage unless you have specified any limit using the options given below.', 'heateor-ssmi-text' ); ?>
					</div>
					<ol>
						<li>
							<div class="h2"><input style="width:40px" type="text" onkeyup="var heateorSsmiTargetElem2 = jQuery(this).parents('ol').next().next(); if(this.value.trim() == ''){jQuery(heateorSsmiTargetElem2).css('display', 'block');}else{jQuery(heateorSsmiTargetElem2).css('display', 'none');}" name="<?php echo $this->field_name( 'no_of_times_per_webpage' ); ?>" id="<?php echo $this->field_id( 'no_of_times_per_webpage' ); ?>" value="<?php echo isset( $prefs['no_of_times_per_webpage'] ) ? $prefs['no_of_times_per_webpage'] : ''; ?>" /></div>
						</li>
					</ol>
					<div style="clear:both"></div>
					<div style="<?php echo isset( $prefs['no_of_times_per_webpage'] ) && $prefs['no_of_times_per_webpage'] ? 'display:none' : ''; ?>" >
						<label class="subheader"><?php _e( 'For sharing a url via the same social network, award points per (leave empty for no limit) ', 'heateor-ssmi-text' ); ?></label>
						<ol>
							<li>
								<div class="h2" style="float:left"><input style="width:40px" type="text" onkeyup="var heateorSsmiTargetElem = jQuery(this).parents('ol').next().next(); if(this.value.trim() == ''){jQuery(heateorSsmiTargetElem).css('display', 'none');}else{jQuery(heateorSsmiTargetElem).css('display', 'block');}" name="<?php echo $this->field_name( 'limit_count' ); ?>" id="<?php echo $this->field_id( 'limit_count' ); ?>" value="<?php echo isset( $prefs['limit_count'] ) ? $prefs['limit_count'] : 1; ?>" /></div>
								<div class="h2" style="float:left"><select style="height:24px" name="<?php echo $this->field_name( 'limit' ); ?>" id="<?php echo $this->field_id( 'limit' ); ?>" >
									<option value="second" <?php echo isset( $prefs['limit'] ) && $prefs['limit'] == 'second' ? 'selected' : '' ?>><?php _e( 'Second(s)', 'heateor-ssmi-text' ) ?></option>
									<option value="minute" <?php echo isset( $prefs['limit'] ) && $prefs['limit'] == 'minute' ? 'selected' : '' ?>><?php _e( 'Minute(s)', 'heateor-ssmi-text' ) ?></option>
									<option value="hour" <?php echo !isset( $prefs['limit'] ) || $prefs['limit'] == 'hour' ? 'selected' : '' ?>><?php _e( 'Hour(s)', 'heateor-ssmi-text' ) ?></option>
									<option value="day" <?php echo isset( $prefs['limit'] ) && $prefs['limit'] == 'day' ? 'selected' : '' ?>><?php _e( 'Day(s)', 'heateor-ssmi-text' ) ?></option>
								</select></div>
							</li>
						</ol>
						<div style="clear:both"></div>
						<div style="<?php echo ! isset( $prefs['limit_count'] ) || $prefs['limit_count'] == '' ? 'display:none' : ''; ?>" >
							<label class="subheader"><?php _e( 'Number of maximum different webpages users can share per social network to earn points (Leave empty for no limit)', 'heateor-ssmi-text' ); ?></label>
							<div style="clear:both">
								<?php _e( 'For example, if you save 3, a user can earn points for sharing 3 different webpages per social network within the specified time limit. User will not get any points for sharing fourth (different OR same) webpage within that time limit. If you leave it empty, users will get points each time they share a different webpage.', 'heateor-ssmi-text' ); ?>
							</div>
							<ol>
								<li>
									<div class="h2"><input style="width:40px" type="text" name="<?php echo $this->field_name( 'limit_pages' ); ?>" id="<?php echo $this->field_id( 'limit_pages' ); ?>" value="<?php echo isset( $prefs['limit_pages'] ) ? $prefs['limit_pages'] : ''; ?>" /></div>
								</li>
							</ol>
						</div>
					</div>
					<?php
				}

			} else {
				echo '<h3 style="color:red">';
				_e( 'Enable sharing from Super Socializer OR Sassy Social Share plugin to see the options', 'heateor-ssmi-text' );
				echo '</h3>';
			}
		}

		/**
		 * Sanitize Preferences
		 */
		public function sanitise_preferences( $data ) {
			$new_data = $data;
			
			if ( $this->sharingOptions ) {
				$horizontal_sharing_networks = isset( $this->sharingOptions['horizontal_re_providers'] ) ? $this->sharingOptions['horizontal_re_providers'] : array();
				$vertical_sharing_networks = isset( $this->sharingOptions['vertical_re_providers'] ) ? $this->sharingOptions['vertical_re_providers'] : array();
				$share_like_buttons = array( 'facebook_share', 'facebook_like', 'facebook_recommend', 'twitter_tweet', 'google_plusone', 'google_plus_share', 'linkedin_share', 'pinterest_pin', 'buffer_share', 'xing_share', 'yummly_share', 'reddit_badge', 'stumbleupon_badge' );
				$sharing_networks = array_diff( array_unique( array_merge( $horizontal_sharing_networks, $vertical_sharing_networks ) ), $share_like_buttons );
				foreach ( $sharing_networks as $network ) {
					$network = ucfirst( $network );
					$new_data[$network . '_log'] = ( ! empty( $data[$network . '_log'] ) ) ? sanitize_text_field( $data[$network . '_log'] ) : $this->defaults[$network . '_log'];
				}

				$horizontal_like_buttons = isset( $this->counterOptions['horizontal_providers'] ) ? array_diff( $this->counterOptions['horizontal_providers'], array( 'googleplus_share', 'linkedin_share', 'pinterest_pin_it', 'xing', 'reddit', 'stumbleupon_badge', 'yummly', 'buffer' ) ) : array();
				$vertical_like_buttons = isset( $this->counterOptions['vertical_providers'] ) ? array_diff( $this->counterOptions['vertical_providers'], array( 'googleplus_share', 'linkedin_share', 'pinterest_pin_it', 'xing', 'reddit', 'stumbleupon_badge', 'yummly', 'buffer' ) ) : array();
				$like_buttons = array_unique( array_merge( $horizontal_like_buttons, $vertical_like_buttons, array_intersect( array( 'facebook_like', 'facebook_recommend', 'twitter_tweet' ), array_unique( array_merge( $horizontal_sharing_networks, $vertical_sharing_networks ) ) ) ) );
				if ( $like_buttons ) {
					foreach ( $like_buttons as $k => $v ) {
						if ( $v == 'facebook_like' || $v == 'facebook_recommend' ) {
							$like_buttons[$k] = 'facebook_like_recommend';
						}
					}
				}
				$like_buttons = array_unique( $like_buttons );

				foreach ( $like_buttons as $network ) {
					$network = ucfirst( $network );
					$new_data[$network . '_log'] = ( ! empty( $data[$network . '_log'] ) ) ? sanitize_text_field( $data[$network . '_log'] ) : $this->defaults[$network . '_log'];
				}

				if ( isset( $this->sharingOptions['horizontal_more'] ) || isset( $this->sharingOptions['vertical_more'] ) ) {
					$new_data['Other_log'] = ( ! empty( $data['Other_log'] ) ) ? sanitize_text_field( $data['Other_log'] ) : $this->defaults['Other_log'];
				}
			}

			return $new_data;
		}
	}
}

/**
 * Show points for Social Sharing with other points being displayed via "mycred_hook_table" shortcode
 */
function heateor_ssmi_sharing_points( $content, $atts ) {
	$content = str_replace(array( '</tbody>', '</table>' ), '', $content );

	$hooks = get_option( 'mycred_pref_hooks' );
	if ( isset( $hooks['active'] ) && strpos( $content, '<table' ) !== false ) {
		$content = str_replace( array( '</tbody>', '</table>' ), '', $content );
		if ( in_array( 'heateor_sharing', $hooks['active'] ) && isset( $hooks['hook_prefs']['heateor_sharing'] ) ) {
			foreach ( $hooks['hook_prefs']['heateor_sharing'] as $key => $val ) {
				if ( $val > 0 && strpos( $key, 'creds' ) !== false ) {
					$key = str_replace( array( '_', 'creds' ), array( ' ', 'Share' ), $key );
					$content .= '<tr>';
					$content .= '<td class="column-instance">Points for ' . $key . '</td>';
					$content .= '<td class="column-amount" colspan="2">' . $val . '</td>';
					$content .= '</tr>';
				}
			}
		}
		if ( isset( $hooks['hook_prefs']['heateor_sharing']['no_of_times_per_webpage'] ) && $hooks['hook_prefs']['heateor_sharing']['no_of_times_per_webpage'] ) {
			$content .= '<tr>';
			$content .= '<td class="column-instance">Number of different webpages a user can share to earn points</td>';
			$content .= '<td class="column-amount" colspan="2">' . $hooks['hook_prefs']['heateor_sharing']['no_of_times_per_webpage'] . '</td>';
			$content .= '</tr>';
		} elseif ( isset( $hooks['hook_prefs']['heateor_sharing']['limit_count'] ) && isset( $hooks['hook_prefs']['heateor_sharing']['limit'] ) ) {
			$content .= '<tr>';
			$content .= '<td class="column-instance">Limit (Points for Social Sharing)</td>';
			$content .= '<td class="column-amount" colspan="2">Maximum once per ' . ( $hooks['hook_prefs']['heateor_sharing']['limit_count'] == 1 ? '' : $hooks['hook_prefs']['heateor_sharing']['limit_count'] ) . " " . $hooks['hook_prefs']['heateor_sharing']['limit'] . '(s)</td>';
			$content .= '</tr>';

			if ( isset( $hooks['hook_prefs']['heateor_sharing']['limit_pages'] ) && $hooks['hook_prefs']['heateor_sharing']['limit_pages'] != '' ) {
				$content .= '<tr>';
				$content .= '<td class="column-instance">Page Limit</td>';
				$content .= '<td class="column-amount" colspan="2">' . 'Maximum ' . $hooks['hook_prefs']['heateor_sharing']['limit_pages'] . ' different page(s) within the time limit specified</td>';
				$content .= '</tr>';
			}
		}
		$content .= '</tbody></table>';
	}
	return $content;
}
add_filter( 'mycred_render_hook_table', 'heateor_ssmi_sharing_points', 10, 2 );


/**
 * Add add-on reference
 */
function heateor_ssmi_add_addon_reference( $list ) {
	$list['heateor_sharing'] = 'Heateor Sharing';
	return $list;
}
add_filter( 'mycred_all_references', 'heateor_ssmi_add_addon_reference' );