function heateorSsmiMycredPoints(e, t, r, i) {
    jQuery.ajax({
        type: "GET",
        dataType: "json",
        url: heateorSsmiAjaxUrl,
        data: {
            action: "heateor_ssmi_share_click",
            provider: e,
            log_provider: "undefined" != typeof t ? t : "",
            url: r,
            deduct: "undefined" != typeof i ? i : ""
        },
        success: function(a, b, c) {}
    })
}

function heateorSsmiGpCallback(e) {
    "on" == e.state ? heateorSsmiMycredPoints("Google_plusone", "", e.href ? e.href : "") : "off" == e.state && heateorSsmiMycredPoints("Google_plusone", "", e.href ? e.href : "", "Minus point(s) for undoing Google +1")
}
jQuery(document).on('click', '.the_champ_sharing_container i, .heateor_sss_sharing_container i', function(){
    var e = jQuery(this).attr("title");
    "More" != e && "Total Shares" != e && ("Google Plus" == e ? e = "Google" : "Float it" == e && (e = "Floatit"), heateorSsmiMycredPoints(e, "", jQuery(this).parents(".the_champ_sharing_container").length ? jQuery(this).parents(".the_champ_sharing_container").attr("super-socializer-data-href") : jQuery(this).parents(".heateor_sss_sharing_container").attr("heateor-sss-data-href")));
});
jQuery(document).on('click', '.theChampMoreBackground, .heateorSssMoreBackground', function(){
    jQuery("#the_champ_sharing_more_content li, #heateor_sss_sharing_more_content li").find("a").click(function(){
        heateorSsmiMycredPoints("Other", jQuery(this).find("i").attr("title"), jQuery(this).parents(".the_champ_sharing_container").length ? jQuery(this).parents(".the_champ_sharing_container").attr("super-socializer-data-href") : jQuery(this).parents(".heateor_sss_sharing_container").attr("heateor-sss-data-href"))
    });
});
jQuery(function(){
    jQuery("#twitter-wjs").load(function(){
        twttr.ready(function(e){
            e.events.bind("tweet", function(e){
                "tweet" == e.type && heateorSsmiMycredPoints("Twitter_tweet", "", jQuery(e.target).parent().attr("heateor-ss-data-href") ? jQuery(e.target).parent().attr("heateor-ss-data-href") : jQuery(e.target).parent().attr("heateor-sss-data-href"))
            })
        })
    })
});