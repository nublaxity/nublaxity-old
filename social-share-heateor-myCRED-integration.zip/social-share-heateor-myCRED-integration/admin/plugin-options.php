<?php defined( 'ABSPATH' ) or die( "Cheating........Uh!!" ); ?>
<h2>Social Share myCRED Integration</h2>
<div class="metabox-holder columns-2" id="post-body">
	<div class="heateor_left_column">
		<div class="stuffbox">
			<h3 class="hndle"><label><?php _e( 'Configuration', 'heateor-ssmi-text' );?></label></h3>
			<div class="inside">
				<p>
					<?php echo sprintf( __( 'Navigate to <a href="%s">Points > Hooks</a> OR <a href="%s">myCRED > Hooks</a> page from left sidebar and activate "Points for Social Sharing" hook.', 'heateor-ssmi-text' ), 'admin.php?page=mycred-hooks', 'admin.php?page=myCRED_page_hooks' ); ?>
				</p>
			</div>
		</div>
	</div>
	<?php require 'help.php' ?>
</div>