<?php
/*
Plugin name:Custom Help Tabs
Version 1.0
*/
add_action( "load-edit.php", 'sp_help_tabs' );
add_action( "load-post.php", 'sp_help_tabs' );
add_filter( 'contextual_help', 'sp_help_tabs', 10, 3 );
function sp_help_tabs() {
    $screen = get_current_screen();
    $screen_ids = array( 'edit-page', 'page' );
    if ( ! in_array( $screen->id, $screen_ids ) ) { return; }
    $screen->remove_help_tabs();
    $screen->add_help_tab(
        array(
            'id'      => 'sp_overview',
            'title'   => 'Overview',
            'content' => '<p>Overview of your plugin or theme here</p>'
        )
    );
    $screen->add_help_tab(
        array(
            'id'      => 'sp_faq',
            'title'   => 'FAQ',
            'content' => '<p>Frequently asked questions and their answers here</p>'
        )
    );
    $screen->add_help_tab(
        array(
            'id'      => 'sp_support',
            'title'   => 'Support',
            'content' => '<p>For support, shoot us a mail via me@w3guy.com</p>'
        )
    );
    // Add a sidebar to contextual help.
    $screen->set_help_sidebar( 'This is the content you will be adding to the sidebar.' );
}
?>
