<?php

/**
 * About the Plugin
 *
 * Hezecom Cpanel Email Manager is a PHP based app which perform cpanel operations
 * without having to login to your cpanel. It enables you to easily create email,
 * list all emails accounts, change email passwords, edit quota and more.
 *
 * @link              http://hezecom.com
 * @since             1.0.0
 * @package           Hezecom_Cpanel_Manager
 *
 * @wordpress-plugin
 * Plugin Name:       HezecomCPM
 * Plugin URI:        http://hezecom.com/hezecom-cpanel-manager
 * Description:       Hezecom Cpanel Email Manager is a WordPress Plugin which perform cpanel operations without having to login to your cpanel.
 * Version:           1.0.0
 * Author:            Hezecom
 * Author URI:        http://hezecom.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       hezecom-cpanel-manager
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-hezecom-cpanel-manager-activator.php
 */
function activate_hezecom_cpanel_manager() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-hezecom-cpanel-manager-activator.php';
	Hezecom_Cpanel_Manager_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-hezecom-cpanel-manager-deactivator.php
 */
function deactivate_hezecom_cpanel_manager() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-hezecom-cpanel-manager-deactivator.php';
	Hezecom_Cpanel_Manager_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_hezecom_cpanel_manager' );
register_deactivation_hook( __FILE__, 'deactivate_hezecom_cpanel_manager' );

/**
 * admin-specific hooks, and public-facing site hooks.
 */
    require plugin_dir_path( __FILE__ ) . 'config/config.php';
    require plugin_dir_path( __FILE__ ) . 'config/config.inc.php';
    require plugin_dir_path( __FILE__ ) . 'includes/class_hezecom_dbcon.php';
    require plugin_dir_path( __FILE__ ) . 'includes/hezecom_functions.php';
    require plugin_dir_path( __FILE__ ) . 'includes/hezecom_xmlapi.php';
    require plugin_dir_path( __FILE__ ) . 'includes/class-hezecom-cpanel-manager.php';
    require plugin_dir_path( __FILE__ ) . 'includes/class_hezecom_cpanel.php';

/**
 * Begins execution of the plugin.
 */
function run_hezecom_cpanel_manager() {

	$plugin = new Hezecom_Cpanel_Manager();
	$plugin->run();

}
run_hezecom_cpanel_manager();

include_once('public/partials/signup.php');
?>
