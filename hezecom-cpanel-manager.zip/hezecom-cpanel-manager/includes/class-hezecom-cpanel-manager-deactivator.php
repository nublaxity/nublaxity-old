<?php

/**
 * Fired during plugin deactivation
 *
 * @link       http://hezecom.com
 * @since      1.0.0
 *
 * @package    Hezecom_Cpanel_Manager
 * @subpackage Hezecom_Cpanel_Manager/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Hezecom_Cpanel_Manager
 * @subpackage Hezecom_Cpanel_Manager/includes
 * @author     Hezecom TS <info@hezecom.net>
 */
class Hezecom_Cpanel_Manager_Deactivator {

	public static function deactivate() {

	}

}
