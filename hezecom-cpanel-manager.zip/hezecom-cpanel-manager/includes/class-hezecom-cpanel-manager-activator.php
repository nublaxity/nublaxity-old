<?php

/**
 * Fired during plugin activation
 *
 * @link       http://hezecom.com
 * @since      1.0.0
 *
 * @package    Hezecom_Cpanel_Manager
 * @subpackage Hezecom_Cpanel_Manager/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Hezecom_Cpanel_Manager
 * @subpackage Hezecom_Cpanel_Manager/includes
 * @author     Hezecom TS <info@hezecom.net>
 */
class Hezecom_Cpanel_Manager_Activator {

	public static function activate() {

        global $wpdb;
        $table_name = $wpdb->prefix . 'mailusers';
        $charset_collate = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE IF NOT EXISTS $table_name (
          `uid` int(11) NOT NULL AUTO_INCREMENT,
          `cfname` varchar(100) NOT NULL,
          `duser` varchar(50) NOT NULL,
          `cusername` varchar(50) NOT NULL,
          `cpassword` varchar(200) NOT NULL,
          `cbirthday` varchar(30) NOT NULL,
          `cgender` varchar(10) NOT NULL,
          `cphone` varchar(50) NOT NULL,
          `cemail` varchar(50) NOT NULL,
          `clocation` varchar(150) NOT NULL,
          `rdate` varchar(50) DEFAULT NULL,
          `user_image` varbinary(50) DEFAULT NULL,
          `user_status` int(11) DEFAULT NULL,
          `email_quota` int(11) DEFAULT NULL,
          PRIMARY KEY (`uid`)
        ) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1;
        ) $charset_collate;";
        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        dbDelta( $sql );
	}

}
