<?php
        /*error_reporting(E_ALL);*/
        /*
        Hezecom Email Solution
        Author: Hezecom Technologies (http://hezecom.com) info@hezecom.net
        COPYRIGHT 2016 ALL RIGHTS RESERVED
        
        You must have purchased a valid license from HEZECOM in order to have 
        access this file.
    
        You may only use this file according to the respective licensing terms 
        you agreed to when purchasing this item.
        */
        

    define('C_URL','nbx.me');
define('C_IP','170.75.163.157');
define('C_USERNAME','nbxme');
define('C_PASSWORD','MamiJu2018!!');
define('C_PORT','2083');

define('DISC_QUOTA','100');

define('H_ADMIN','admin.php');

define('RECORD_PER_PAGE','20');

?>