<?php /* Hezecom Email Solution Author: Hezecom Technologies (http://hezecom.com) info@hezecom.net License Information */ 
 define('LICENSE_USER','nublaxity');
define('LICENSE_CODE','7b1c784e-a13e-4689-a08b-89fa0fa6089d');
define('LICENSE_EMAIL','taniasiyam@gmail.com');

?>