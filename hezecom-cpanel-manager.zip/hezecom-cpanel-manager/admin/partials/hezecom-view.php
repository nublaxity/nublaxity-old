<?php
/*
Hezecom Email Solution
Author: Hezecom Technologies (http://hezecom.com) info@hezecom.net
COPYRIGHT 2016 ALL RIGHTS RESERVED

You must have purchased a valid license from HEZECOM in order to have
access this file.

You may only use this file according to the respective licensing terms
you agreed to when purchasing this item.
*/
$result = SelectEmails(RECORD_PER_PAGE);
$paging = pagination(CountRow(),RECORD_PER_PAGE,''.H_ADMIN.'?page=hezecom-cpm&email='.get('email').'&hezecom_submit=Search');
if(get('uid') and get('do')=='delete'){
    $new = new MyCpanel();
    $response=$new->HezecomDeleteEmail(get('user'));
        if (strpos($response, 'error')=== false) {
            Delete(get('uid'), H_ADMIN . '?page=hezecom-cpm');
        }
}
?>
<script>
    /*confirm delete*/
    //MODAL BOX
    $(document).ready(function() {
     $('a[data-confirm]').click(function(ev) {
     var href = $(this).attr('href');
     if (!$('#dataConfirmModal').length) {
     $('body').append('<div id="dataConfirmModal" class="modal fade" role="dialog" aria-labelledby="dataConfirmLabel" aria-hidden="true"><div class="modal-dialog"><div class="modal-content"><div class="modal-header"><button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button><h3 id="dataConfirmLabel">Please Confirm</h3></div><div class="modal-body"></div><div class="modal-footer"><button class="btn btn-danger" data-dismiss="modal" aria-hidden="true">Cancel</button><a class="btn btn-primary" id="dataConfirmOK">Yes</a></div></div></div></div>');
     }
     $('#dataConfirmModal').find('.modal-body').text($(this).attr('data-confirm'));
     $('#dataConfirmOK').attr('href', href);
     $('#dataConfirmModal').modal({show:true});
     return false;
     });
     });

    /*TOOL TIP*/
    $(document).ready(function() {
        $(".tip").tooltip();
    });


</script>
<div class="wrap">
    <div class="col-lg-12">
        <h4 class="text-muted"><?php echo esc_html(get_admin_page_title()); ?> <a href="<?php echo H_ADMIN;?>?page=hezecom-signup" class="btn btn-info btn-sm tip" title="Create Account"><i class="fa fa-plus"></i> Create Email Account</a></h4>
    </div>
    <div class="col-lg-12">
        <div class="panel panel-default">
            <!-- Default panel contents -->
            <div class="panel-heading"><h3 class="panel-title"><i class="fa fa-reorder"></i> <strong>Email Account</strong></h3></div>
            <div class="panel-body">
                <form id="my-form"  method="get">
                    <input type="hidden" name="page" value="hezecom-cpm">
                <div class="row">
                    <div class="form-group col-xs-12 col-md-2">
                        <input id="filter" class="input-sm" name="email" value="<?php echo esc_attr( get("email")) ?>" type="text" placeholder="search email"/>
                    </div>
                    <div class="form-group col-xs-12 col-md-1">
                        <input type="submit" name="hezecom_submit" class="btn btn-info btn-sm" value="Search" id="form-submit">
                    </div>
                </div>
                </form>
            </div>

            <table class="table table-bordered table-hover table-striped">
                <thead>
                <tr>
                    <th width="20%">Name</th>
                    <th width="20%">Email</th>
                    <th width="20%">Alternate Email</th>
                    <th width="10%">Disc Quota</th>
                    <th width="30%">Actions</th>
                </tr>
                </thead>
                <tbody>

                <?php
                foreach($result as $rows)
                {
                    ?>
                    <tr>
                        <td><?php echo $rows->cfname;?></td>
                        <td><?php echo $rows->cusername;?></td>
                        <td><?php echo $rows->cemail;?></td>
                        <td><a class="btn btn-info btn-xs"><?php echo $rows->email_quota;?>MB</a></td>

                        <td class="table-actions">
                            <div class="btn-group">
                                <a href="<?php echo H_ADMIN;?>?page=hezecom-cpm&uid=<?php echo $rows->uid;?>&do=update&act=quota"  class="btn btn-success btn-xs"><span class="fa fa-edit tip" title="Quota"></span> Quota</a>
                                <a href="<?php echo H_ADMIN;?>?page=hezecom-cpm&uid=<?php echo $rows->uid;?>&do=update&act=pwd"  class="btn btn-default btn-xs"><span class="fa fa-lock tip" title="Password"></span> Password</a>
                                <a href="<?php echo H_ADMIN;?>?page=hezecom-cpm&uid=<?php echo $rows->uid;?>&do=details"  class="btn btn-info btn-xs"><span class="fa fa-search-plus tip" title="Details"></span></a>
                                <a href="<?php echo H_ADMIN;?>?page=hezecom-cpm&uid=<?php echo $rows->uid;?>&do=update" class="btn btn-primary btn-xs"><span class="fa fa-edit tip" title="Update"></span></a>
                                <a href="<?php echo H_ADMIN;?>?page=hezecom-cpm&uid=<?php echo $rows->uid;?>&do=delete&user=<?php echo $rows->cusername;?>" class="btn btn-danger btn-xs" data-confirm="Are you sure you want to delete this record?"> <span class="fa fa-times tip" title="Delete"></span></a>
                            </div>
                        </td>
                    </tr>
                <?php }?>
                </tbody>
            </table>
            <ul class="pagination"><?php echo $paging;?></ul>

        </div>
    </div><!--/col-12-->
</div>