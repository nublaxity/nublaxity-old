<?php
/**
 * Author: Hezecom Technology Solutions LTD.
 * Contact: hezecom.com <info@hezecom.net>
 * User: Hezecom
 * Date: 12/29/2016
 * Time: 5:26 PM
 */

defined( 'ABSPATH' ) or die( 'No source found!' );

if ( !class_exists('HezecomCPM_AdminForm', false) ) {
    class HezecomCPM_AdminForm {
        public function __construct() {
            add_action( 'wp_ajax_hezecomform_action', 'hezecomcpm_form_action' );
        }

        public function HezecomCPM_AdminSignup() {
            $form ='
   <script>
        (function() {

            var PasswordToggler = function( element, field ) {
                this.element = element;
                this.field = field;

                this.toggle();
            };

            PasswordToggler.prototype = {
                toggle: function() {
                    var self = this;
                    self.element.addEventListener( "change", function() {
                        if( self.element.checked ) {
                            self.field.setAttribute( "type", "text" );
                        } else {
                            self.field.setAttribute( "type", "password" );
                        }
                    }, false);
                }
            };
            document.addEventListener( "DOMContentLoaded", function() {
                var checkbox = document.querySelector( "#show-hide" ),
                    pwd = document.querySelector( "#pwd" ),
                    form = document.querySelector( "#my-form" );

                /*form.addEventListener( "submit", function( e ) {
                 e.preventDefault();
                 }, false);*/

                var toggler = new PasswordToggler( checkbox, pwd );

            });

        })();

    </script>
<div  class="wrap" >
        <div class="row">
            <div class="col-lg-12">
                <h4 class="text-muted">'.esc_html(get_admin_page_title()).'</h4>
            </div>
            <div class="col-lg-12">
                <h4>Create Account</h4>
            </div>
        </div>
        
        <form id="hezecomcpm-form" role="form">
        <div class="row">
                <div class="form-group col-md-6">
                    <label for="fname">Name</label>
                    <input type="text" class="form-control input-lg"  pattern="[a-zA-Z0-9 ]+"  name="fname" id="fname" maxlength="50" placeholder="Name" required>
                </div>
            </div>


            <div class="row">
                <div class="form-group col-xs-12 col-md-6">
                    <label for="username">Username</label>
                    <div class="input-group">
                    <input name="username" type="text" class="form-control input-lg" id="username" pattern="[a-zA-Z0-9 ]+" maxlength="15" placeholder="Enter Username" required>
                    <div class="input-group-addon">@'.C_URL.'</div>
                        </div>
                </div>
            </div>

            <div class="row">
                <div class="form-group col-xs-12 col-md-6">
                    <label for="username">Password</label>
                    <div class="input-group">
                    <input type="password" class="form-control input-lg" name="pwd" id="pwd" placeholder="Password" onKeyUp="PwdStrength(this.value)" required>
                        <div class="input-group-addon"> <input type="checkbox" id="show-hide" name="show-hide" value="" />
                            <label for="show-hide">Show password</label></div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="form-group col-xs-12 col-md-6">
                    <div id="PwdDescription"></div>
                    <div id="PwdStrength" class="strength0"></div>
                </div>
            </div>

            <div class="row">
                <div class="form-group col-xs-12 col-md-6">
                    <label for="forwarding">Add Forwarding</label>
                    <input type="text" class="form-control input-lg" name="forwarding" placeholder="e.g. mymail@gmail.com" >
                </div>
            </div>

            <div class="row">
                <div class="form-group col-xs-12 col-md-6">
                    <label for="email">Alternate Email</label>
                    <input type="email" class="form-control input-lg" name="email" placeholder="Alternate Email">
                </div>
            </div>

            <div class="row">

                <div class="form-group col-xs-12 col-md-3">
                    <div class="input-group">
                        <div class="input-group-addon">Quota (MB)</div>
                    <input type="text" class="form-control input-lg" name="custom_quota" placeholder="Quota" value="'.DISC_QUOTA.'">
                </div>
                </div>

            </div>

            <div class="row">
                <div class="form-group col-xs-12 col-md-2">
					<input type="hidden" name="action" value="hezecomform_action" />
			<button id="cpmbutton" type="button" class="btn btn-info btn-lg">Create Account</button>
                </div>
				
                <div class="form-group col-xs-12 col-md-2">
                    <a href="'.H_ADMIN.'?page=hezecom-cpm" class="btn btn-default btn-lg">Go Back</a>
                </div>
            </div>

        </form>
		<div id="contact-msg" class="error-message"></div>
        </div>';

            echo $form;
        }


        /**
         * action
         */
        public function hezecomcpm_form_action() {
            if($_POST){

                global $wpdb;
                $new = new MyCpanel();
                $db = DB::getInstance();
                $table_name = $wpdb->prefix . 'mailusers';
                $fname = sanitize_text_field(post("fname"));
                $cusername = sanitize_text_field(post("username"));
                $cpassword = sanitize_text_field(post("pwd"));
                $cemail = sanitize_email(post("email"));
                $forwarding = sanitize_email(post("forwarding"));
                $email_quota = sanitize_text_field(post("custom_quota"));
                $rdate = date('Y-m-d');
                $email_account = $cusername . '@' . C_URL;

                $error = '';
                $status = 'error';
                if (empty($_POST['fname'])) {
                    $error = __( 'Please enter your name' );
                }
                elseif(strlen($cusername)<3) {
                    $error = __('Please enter your username without @' );
                }
                elseif (strlen($cpassword) < 6) {
                    $error = __('Your password is too short!');
                }
                elseif (!preg_match("#[0-9]+#", $cpassword)) {
                    $error = __( 'Password must include at least one number!');
                }
                elseif (!preg_match("#[a-zA-Z]+#", $cpassword)) {
                    $error = __('Password must include at least one letter!');
                }
                elseif( !preg_match("#[A-Z]+#", $cpassword) ) {
                    $error = __('Password must include at least one CAPS!');
                }
                elseif( !preg_match("#\W+#", $cpassword) ) {
                    $error = __('Password must include at least one symbol!');
                }

                elseif (user_exist_checker($email_account, $table_name) === true) {
                    $error = __( $email_account . ' Already Exist');
                }
                else {

                    $response = $new->HezecomAddEmail($email_account, $cpassword, $email_quota);
                    if (strpos($response, 'error') === false) {

                        if ($forwarding) {
                            $new->HezecomEmailForward($email_account, $forwarding);
                        }
                        $finalpwd = hezecom_crypt($cpassword);
                        $userdata = array('user_login'=>$cusername,'first_name'=>$fname,'user_email'=>$email_account,'user_pass'=>$cpassword);
                        wp_insert_user( $userdata ) ;
                        HezecomInsert($fname, $cusername, $email_account, $finalpwd, $cemail, $email_quota, $rdate);
                        $status = 'success';
                        $error =  __( 'Email account created successfuly!');

                    }else{
                        $status = 'error';
                        $error =  __( 'Problem occurred while trying to create email account. Please check your cpanel settings!');
                    }
                }

                $resp = array('status' => $status, 'errmessage' => $error);
                wp_send_json($resp);
            }

        }
    }

}
