
<?php
/*
Hezecom Email Solution
Author: Hezecom Technologies (http://hezecom.com) info@hezecom.net
COPYRIGHT 2016 ALL RIGHTS RESERVED

You must have purchased a valid license from HEZECOM/codecanyon.net in order to have
access this file.

You may only use this file according to the respective licensing terms
you agreed to when purchasing this item.
*/
$rows=SelectOne(get('uid'));
$new = new MyCpanel();
if(get('user') and get('fwd')){
    $new->HezecomDeleteEmailForward(get('user'),get('fwd'));
}
$response=$new->HezecomListEmailOne($rows->cusername);
$forwarder=$new->HezecomListEmailForward($rows->duser);
?>
<script>
    /*confirm delete*/
    //MODAL BOX
    $(document).ready(function() {
        $('a[data-confirm]').click(function(ev) {
            var href = $(this).attr('href');
            if (!$('#dataConfirmModal').length) {
                $('body').append('<div id="dataConfirmModal" class="modal fade" role="dialog" aria-labelledby="dataConfirmLabel" aria-hidden="true"><div class="modal-dialog"><div class="modal-content"><div class="modal-header"><button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button><h3 id="dataConfirmLabel">Please Confirm</h3></div><div class="modal-body"></div><div class="modal-footer"><button class="btn btn-danger" data-dismiss="modal" aria-hidden="true">Cancel</button><a class="btn btn-primary" id="dataConfirmOK">Yes</a></div></div></div></div>');
            }
            $('#dataConfirmModal').find('.modal-body').text($(this).attr('data-confirm'));
            $('#dataConfirmOK').attr('href', href);
            $('#dataConfirmModal').modal({show:true});
            return false;
        });
    });

    /*TOOL TIP*/
    $(document).ready(function() {
        $(".tip").tooltip();
    });


</script>
<div class="wrap">
    <div class="col-lg-10">
        <h4 class="text-muted"><?php echo esc_html(get_admin_page_title()); ?> <a href="<?php echo H_ADMIN;?>?page=hezecom-signup" class="btn btn-info btn-sm tip" title="Create Account"><i class="fa fa-plus"></i> Create Email Account</a></h4>
        <p><?php if(get('msg')){json_success('Email account updated!');}?></p>
    </div>
    <div class="col-lg-10">

        <ul class="nav nav-tabs pull-right">
            <a href="<?php echo H_ADMIN;?>?page=hezecom-cpm" class="btn btn-default btn-sm tip" title="Go back"><i class="fa fa-reply"></i> Go Back</a>
            <a href="<?php echo H_ADMIN;?>?page=hezecom-cpm&uid=<?php echo $rows->uid;?>&do=update&act=pwd" title="Update Password" class="btn btn-default btn-sm tip"><i class="fa fa-lock"></i> Password</a>
            <a href="<?php echo H_ADMIN;?>?page=hezecom-cpm&uid=<?php echo $rows->uid;?>&do=update&act=quota" title="Update Quota" class="btn btn-default btn-sm tip"><i class="fa fa-edit"></i> Quota</a>
            <a href="<?php echo H_ADMIN;?>?page=hezecom-cpm&uid=<?php echo $rows->uid;?>&do=update" title="Update" class="btn btn-default btn-sm tip"><i class="fa fa-edit"></i> Update</a>
            <a href="<?php echo H_ADMIN;?>?page=hezecom-cpm&uid=<?php echo $rows->uid;?>&do=delete" title="Delete" class="btn btn-default btn-sm tip" data-confirm="Are you sure you want to delete this record?"><i class="fa fa-trash-o"></i> Delete</a>
        </ul>

        <div class="panel panel-default">
            <!-- Default panel contents -->
            <div class="panel-heading"><h3 class="panel-title"><i class="fa fa-reorder"></i> <strong>Account Details</strong></h3></div>

            <table class="table table-striped table-bordered">
                <tbody>

                <tr>
                    <th>Name</th><td><?php echo $rows->cfname;?></td>
                </tr>
                <tr>
                    <th>Email</th><td><?php echo $rows->cusername;?></td>
                </tr>

                <tr>
                    <th>Alternate Email</th><td colspan="2"><?php echo $rows->cemail;?></td>
                </tr>

                <tr>
                    <th>Quota</th><td colspan="2"><?php echo $rows->email_quota;?> <?php //echo $response->_diskused;?></td>
                </tr>

                <tr>
                    <th>Date</th><td colspan="2"><?php echo $rows->rdate;?></td>
                </tr>
                <tr>

                </tbody>
            </table>
        </div>
        <h4>Email Forwarding</h4>
        <table class="table table-bordered table-hover table-striped">
            <thead>
            <tr>
                <th width="20%">Forwarded to: <a href="<?php echo H_ADMIN;?>?page=hezecom-cpm&uid=<?php echo $rows->uid;?>&do=update&act=forward" class="btn btn-info btn-sm tip" title="Add Forwarding"><i class="fa fa-plus"></i> Add Forwarding</a></th>
            </tr>
            </thead>
            <tbody>
            <?php
             foreach($forwarder as $forw)
             {
                 if($forw->forward!='' and $forw->dest==$rows->cusername){
            ?>
            <tr>
                <td><?php echo $forw->forward;?> <a href="<?php echo H_ADMIN;?>?page=hezecom-cpm&uid=<?php echo $rows->uid;?>&do=details&user=<?php echo $rows->cusername;?>&fwd=<?php echo $forw->forward;?>&msg=1" class="btn btn-danger btn-xs tip" title="Delete Forwarding" data-confirm="Are you sure you want to delete this record?"><i class="fa fa-times"></i> Delete</a></td>
            </tr>
            <?php }}?>
            </tbody>
        </table>
    </div><!--/col-12-->
</div><!--/heze-table-->
	