<?php
/**
 * Author: Hezecom Technology Solutions LTD.
 * Contact: hezecom.com <info@hezecom.net>
 * User: Hezecom
 * Date: 12/2/2016
 * Time: 8:52 AM
 */
$rows=SelectOne(get('uid'));
?>

    <div id="just-contact-form-wrap" class="wrap">
        <div class="row">
            <div class="col-lg-12">
                <h4 class="text-muted"><?php echo esc_html(get_admin_page_title()); ?> <br><br>User: <?php echo $rows->cusername;?></h4>
            </div>
        </div>
        <form id="my-form" action="<?php echo esc_url( $_SERVER['REQUEST_URI'] ); ?>" method="post">

            <input type="hidden" name="uid" value="<?php echo $rows->uid;?>">
            <input type="hidden" name="cusername" value="<?php echo $rows->cusername;?>">
            <input type="hidden" name="duser" value="<?php echo $rows->duser;?>">

<?php if(get('page')=='hezecom-cpm' and get('act')==''){ ?>
            <div class="row">
                <div class="form-group col-xs-12 col-md-6">
                    <h4>Update Account Info</h4>
                </div>
            </div>
            <div class="row">
                <div class="form-group col-md-6">
                    <label for="name">Name</label>
                    <input type="text" class="form-control input-lg" value="<?php echo $rows->cfname;?>" pattern="[a-zA-Z0-9 ]+"  name="fname" id="fname" maxlength="50" placeholder="Name" required>
                </div>
            </div>

            <div class="row">
                <div class="form-group col-xs-12 col-md-6">
                    <label for="cemail">Alternate Email</label>
                    <input type="email" class="form-control input-lg" name="email" placeholder="Alternate Email" value="<?php echo $rows->cemail;?>">
                </div>
            </div>
<?php } elseif(get('page')=='hezecom-cpm' and get('act')=='pwd'){ ?>
            <div class="row">
                <div class="form-group col-xs-12 col-md-6">
                    <h4>Change Password</h4>
                </div>
            </div>

            <div class="row">
                <div class="form-group col-xs-12 col-md-3">
                    <input type="password" class="form-control input-lg" name="pwd" id="pwd" placeholder="Password" onKeyUp="PwdStrength(this.value)" >
                </div>
                <div class="form-group col-xs-12 col-md-3">
                    <input type="password" name="pwd2" value="" class="form-control input-lg" placeholder="Confirm Password"/>
                </div>
            </div>

            <div class="row">
                <div class="form-group col-xs-12 col-md-6">
                    <div id="PwdDescription"></div>
                    <div id="PwdStrength" class="strength0"></div>
                </div>
            </div>

<?php } elseif(get('page')=='hezecom-cpm' and get('act')=='quota'){ ?>
            <div class="row">
                <div class="form-group col-xs-12 col-md-6">
                    <h4>Change Quota</h4>
                </div>
            </div>
            <div class="row">
                <div class="form-group col-xs-12 col-md-3">
                    <div class="input-group">
                        <div class="input-group-addon">Quota (MB)</div>
                        <input type="text" class="form-control input-lg" name="custom_quota" placeholder="Quota" value="<?php echo $rows->email_quota;?>">
                    </div>
                </div>
            </div>
<?php } elseif(get('page')=='hezecom-cpm' and get('act')=='forward'){ ?>

            <div class="row">
                <div class="form-group col-xs-12 col-md-6">
                    <h4>Add Forwarding</h4>
                </div>
            </div>
            <div class="row">
                <div class="form-group col-xs-12 col-md-6">
                    <label for="forwarding">Add Forwarding</label>
                    <input type="text" class="form-control input-lg" name="forwarding" placeholder="e.g. mymail@gmail.com" value="<?php echo post("forwarding");?>">
                </div>
            </div>
<?php }  ?>
            <div class="row">
                <div class="form-group col-xs-12 col-md-2">
                    <input type="submit" name="hezecom_submit" class="btn btn-info btn-lg" value="Update Account" id="form-submit">
                </div>
                <div class="form-group col-xs-12 col-md-2">
                    <a href="<?php echo H_ADMIN;?>?page=hezecom-cpm" class="btn btn-default btn-lg">Go Back</a>
                </div>
            </div>

            <div class="row">
                <div class="form-group col-xs-12 col-md-6">
                    <p id="ajax-load" style="display:none;"><i class="fa fa-spinner fa-spin fa-2x"></i> Processing...</p>
                </div>
            </div>

        </form>

        <div class="row">
            <div class="form-group col-xs-12 col-md-6">
                <div id="result" class="alert alert-success " style="display:none;"></div>
            </div>
        </div>

    </div>


<?php
if( isset($_POST['hezecom_submit']) and $_SERVER['REQUEST_METHOD'] == "POST") {
    global $wpdb;
    $new=new MyCpanel();
    $db = DB::getInstance();
    $table_name = $wpdb->prefix . 'mailusers';
    $fname = sanitize_text_field(post("fname"));
    $duser = sanitize_text_field(post("duser"));
    $cpassword = sanitize_text_field(post("pwd"));
    $cpassword2 = sanitize_text_field(post("pwd2"));
    $forwarding = sanitize_email(post("forwarding"));
    $cemail = sanitize_email(post("email"));
    $email_quota = sanitize_text_field(post("custom_quota"));
    $userEmail = sanitize_text_field(post("cusername"));

    if (!empty($cpassword) and $cpassword != $cpassword2) {
        json_error('Your password are not the same');
    }
    else {

        if(get('page')=='hezecom-cpm' and get('act')==''){
            HezecomUpdate($fname,$cemail,post('uid'));
        }
        elseif(get('page')=='hezecom-cpm' and get('act')=='pwd'){
            $response=$new->HezecomChangeEmailPwd($userEmail,$cpassword);
            if (strpos($response, 'error')=== false) {
                $finalpwd = hezecom_crypt($cpassword);
                HezecomUpdatePassword($finalpwd, post('uid'));
            }else{
                json_error('Invalid cpanel response');
            }
        }
        elseif(get('page')=='hezecom-cpm' and get('act')=='quota'){
            $response=$new->HezecomEditQuota($duser,$email_quota);
            if (strpos($response, 'error')=== false) {
                HezecomUpdateQuota($email_quota, post('uid'));
            }else{
                json_error('Invalid cpanel response');
            }
        }
        elseif(get('page')=='hezecom-cpm' and get('act')=='forward'){
            $new->HezecomEmailForward($userEmail,$forwarding);
        }
        send_to(H_ADMIN."?page=hezecom-cpm&uid=".post('uid')."&do=details&msg=1");
       json_success('Email account updated!');

    }
}

?>