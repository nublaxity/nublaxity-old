<?php
/*
Hezecom Email Solution
Author: Hezecom Technologies (http://hezecom.com) info@hezecom.net
COPYRIGHT 2016 ALL RIGHTS RESERVED

You must have purchased a valid license from HEZECOM/codecanyon.net in order to have
access this file.

You may only use this file according to the respective licensing terms
you agreed to when purchasing this item.
*/
if (isset($_POST['post-settings'])) {
    $phpopen = "<?php
        /*error_reporting(E_ALL);*/
        /*
        Hezecom Email Solution
        Author: Hezecom Technologies (http://hezecom.com) info@hezecom.net
        COPYRIGHT 2016 ALL RIGHTS RESERVED
        
        You must have purchased a valid license from HEZECOM in order to have 
        access this file.
    
        You may only use this file according to the respective licensing terms 
        you agreed to when purchasing this item.
        */
        "."\n
    ";

    $dir = plugin_dir_path(__FILE__) . '../../config/config.php';
    if ($dir) {
        $file = fopen($dir, 'w') or die("can't open file");

        fwrite($file, $phpopen);
        fwrite($file, "define('C_URL'," . "'" . $_POST['url'] . '' . "'" . ')' . ';' . "\n");
        fwrite($file, "define('C_IP'," . "'" . $_POST['ip'] . '' . "'" . ')' . ';' . "\n");
        fwrite($file, "define('C_USERNAME'," . "'" . $_POST['cuser'] . '' . "'" . ')' . ';' . "\n");
        fwrite($file, "define('C_PASSWORD'," . "'" . $_POST['cpwd'] . '' . "'" . ')' . ';' . "\n");
        fwrite($file, "define('C_PORT'," . "'" . $_POST['port'] . '' . "'" . ')' . ';' . "\n\n");
        fwrite($file, "define('DISC_QUOTA'," . "'" . $_POST['quota'] . '' . "'" . ')' . ';' . "\n\n");
        fwrite($file, "define('H_ADMIN',"."'".'admin.php'.''."'".')'.';'."\n\n");
        fwrite($file, "define('RECORD_PER_PAGE',"."'".'20'.''."'".')'.';'."\n\n");
        fwrite($file, "?>");
        fclose($file);
    }

    $msg='Setting Updated Successfully';
}
?>

<div class="wrap">
    <h2><?php echo esc_html(get_admin_page_title()); ?></h2>
    <form method="post"  action="<?php echo esc_url( $_SERVER['REQUEST_URI'] );?>">
        <div class="row">
            <div class="col-md-8">
                <div class="row">
                    <div class="col-md-8 col-xs-12">
                        <h4>Host Settings</h4>
                        <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-addon left">Domain Name</div>
                                <input name="url" type="text" id="url" value="<?php echo C_URL; ?>" class="form-control">
                            </div>
                            <small>This is your website address <i>e.g yourname.com</i></small>
                        </div>

                        <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-addon left">Host IP Address</div>
                                <input name="ip" type="text" id="ip" value="<?php echo C_IP; ?>" class="form-control">
                            </div>
                            <small>This is your host ip address <i>e.g 267.200.20.100</i></small>
                        </div>

                        <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-addon left">Cpanel Username</div>
                                <input name="cuser" type="text" id="cuser" value="<?php echo C_USERNAME; ?>" class="form-control">
                            </div>
                            <small>This is your host username</small>
                        </div>

                        <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-addon left">Host Password</div>
                                <input name="cpwd" type="password" id="cpwd" value="<?php echo C_PASSWORD; ?>" class="form-control">
                            </div>
                            <small>This is your host password</small>
                        </div>

                        <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-addon left">Host Port</div>
                                <input name="port" type="text" class="form-control" id="port" value="<?php echo C_PORT; ?>" >
                            </div>
                            <small><i>please leave this if you are not sure(default port is 2083)</i></small>
                        </div>

                        <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-addon left">Disc Quota</div>
                                <input name="quota" type="text" id="quota" value="<?php echo DISC_QUOTA; ?>" class="form-control">
                            </div>
                            <small>This is the max disc size per user in MB</small>
                        </div>
                    </div><!--/com-md-6-->
                </div>
            </div>
            <div class="col-md-3 col-xs-12">
                <div class="row">
                    <p style="font-size: large;">If you have not, click on the button below to validate your purchase license.</p>
                    <a href="<?php echo H_ADMIN;?>?page=hezecom-settings&do=license" class="btn btn-success">Activate License</a>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-3">
                <div class="control-group">
                    <button type="submit" name="post-settings" class="btn btn-info signup-btn" id="msgButton">Update Settings</button>
                </div>
            </div>
            <div class="col-md-4">
                <div class="control-group">
                    <?php if(isset($msg)){?>
                        <div class="alert alert-success "><?php  echo $msg;?></div>
                    <?php }?>
                </div>
            </div>
        </div>

    </form>

</div>
