Thanks for purchasing Hezecom Cpanel Email Manager!

You may only use this file according to the respective licensing terms you agreed to when purchasing this item.

***** INSTALLATION *****

To install the plugin follow the instructions below:

1. Inside your WordPress admin click on Plugins on the menu then click Add New

2. Click on Upload

3. Browse to the location of the iphorm-form-builder.zip file you downloaded from CodeCanyon

4. Click Install Now

5. Once the plugin has been installed, click Activate plugin

(Alternatively, unzip the hezecom-cpanel-manager.zip file and upload the folder to the wp-content/plugins/ folder. Then go to Plugins on
the WordPress menu and activate the Quform plugin.)

***** ACTIVATION *****

You can now configure the HezecomCPM settings by going to HezecomCPM  -> Settings in the WordPress admin menu.

Please you will need to activate your license before using this plugin.
Once you have obtained your purchase code, enter it in the HezecomCPM -> Settings page within WordPress.

***** SHORTCODE *****
[HezecomCPM_Form]

***** SUPPORT *****
Please contact us for support at:
info@hezecom.net


Best Regards, HezecomTS
