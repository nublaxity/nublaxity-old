<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       http://hezecom.com
 * @since      1.0.0
 *
 * @package    Hezecom_Cpanel_Manager
 * @subpackage Hezecom_Cpanel_Manager/public
 */

/**
 * The public-facing functionality of the plugin.
 * @package    Hezecom_Cpanel_Manager
 * @subpackage Hezecom_Cpanel_Manager/public
 * @author     Hezecom TS <info@hezecom.net>
 */
class Hezecom_Cpanel_Manager_Public {


	private $plugin_name;
	private $version;

	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	public function enqueue_styles() {

    }

	public function enqueue_scripts() {
        wp_enqueue_script($this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/hezecom.public.js', array( 'jquery' ) );
        wp_localize_script($this->plugin_name, 'ajax_object_hcpm', array( 'ajax_url' => admin_url( 'admin-ajax.php' ) ) );
    }




}
