<?php

function HezecomCPM_Signup() {
    $form ='
<style>

.form-control {
    background-color: #fff;
    background-image: none;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-shadow: 0 1px 1px rgba(0, 0, 0, 0.075) inset;
    color: #555;
    display: block;
    font-size: 14px;
    height: 34px;
    line-height: 1.42857;
    padding: 6px 12px;
    transition: border-color 0.15s ease-in-out 0s, box-shadow 0.15s ease-in-out 0s;
    vertical-align: middle;
    width:100%;
    margin-bottom: 8px;
}

textarea.form-control {
    height: auto;
}

label {
    display: inline-block;
    font-weight: bold;
    margin-bottom: 5px;
}

.btn {
    -moz-user-select: none;
    background-image: none;
    border: 1px solid transparent;
    border-radius: 4px;
    cursor: pointer;
    display: inline-block;
    font-size: 14px;
    font-weight: normal;
    line-height: 1.42857;
    margin-bottom: 0;
    padding: 6px 12px;
    text-align: center;
    vertical-align: middle;
    white-space: nowrap;
}
.text-right {
    text-align: right;
}
.error-message {
	margin-top:15px;
	color:#E73A3D;
	font-weight:bold;
	font-family:Gotham, "Helvetica Neue", Helvetica, Arial, sans-serif;
}

    /*Password strenght*/
    #PwdStrength{height:10px;display:block;float:left;}
    .strength0{width:100%;background:#F4F4F4;}
    .strength1{width:30%;background:#ff0000;}
    .strength2{width:50%;	background:#FC0;}
    .strength3{width:70%;background:#56e500;}
    .strength4{background:#4dcd00;width:80%;}
    .strength5{background:#399800;width:100%;}


</style>
   <script>
        (function() {
            var PasswordToggler = function( element, field ) {
                this.element = element;
                this.field = field;
                this.toggle();
            };
            PasswordToggler.prototype = {
                toggle: function() {
                    var self = this;
                    self.element.addEventListener( "change", function() {
                        if( self.element.checked ) {
                            self.field.setAttribute( "type", "text" );
                        } else {
                            self.field.setAttribute( "type", "password" );
                        }
                    }, false);
                }
            };
            document.addEventListener( "DOMContentLoaded", function() {
                var checkbox = document.querySelector( "#show-hide" ),
                    pwd = document.querySelector( "#pwd" ),
                    form = document.querySelector( "#my-form" );
                var toggler = new PasswordToggler( checkbox, pwd );

            });

        })();

    </script>
        <form id="hezecomcpm-form" role="form">
        <input type="hidden"name="custom_quota" placeholder="Quota" value="'.DISC_QUOTA.'">
		
		<div class="form-group">
			<label for="name">Name:</label>
			<input class="form-control" type="text" name="fname" id="fname" maxlength="50" pattern="[a-zA-Z0-9 ]+" placeholder="Enter your name" required>
		</div>
		 
			<div class="form-group">
			<label for="name">Username:</label>
            <input class="form-control" name="username" type="text" id="username"  pattern="[a-zA-Z0-9 ]+" maxlength="30" placeholder="Enter Username" autocomplete="off" required>
            <div class="alert alert-success"><span id="target"></span>@'. C_URL.'</div>
</div>
            
			<div class="form-group">
			<label for=ame">Password:</label>
            <input class="form-control" type="password" name="pwd" id="pwd" placeholder="Password" onKeyUp="PwdStrength(this.value)" required>
            <input type="checkbox" id="show-hide" name="show-hide" value="" />
            <label for="show-hide">Show password</label>
            <div id="PwdDescription"></div>
            <div id="PwdStrength" class="strength0"></div><br>
</div>
		<div class="form-group">
			<label for=ame">Add Forwarding:</label>
            <input class="form-control" type="text" name="forwarding" id="forwarding" placeholder="e.g. mymail@gmail.com" maxlength="80">
        </div>

		<div class="form-group">
			<label for=ame">Alternate Email:</label>
            <input class="form-control" type="email" name="email" placeholder="Alternate Email"  id="email" maxlength="80">
        </div>
			
       <div class="form-group">
			<input type="hidden" name="action" value="hezecomform_action" />
			<button class="btn btn-info" id="cpmbutton" type="button">Create Account</button>
		</div>
        </form>
		<div id="contact-msg" class="error-message"></div>
		';

    echo $form;
}


function hezecomcpm_form_action() {
    if($_POST){

        global $wpdb;
        $new = new MyCpanel();
        $db = DB::getInstance();
        $table_name = $wpdb->prefix . 'mailusers';
        $fname = sanitize_text_field(post("fname"));
        $cusername = sanitize_text_field(post("username"));
        $cpassword = sanitize_text_field(post("pwd"));
        $cemail = sanitize_email(post("email"));
        $forwarding = sanitize_email(post("forwarding"));
        $email_quota = sanitize_text_field(post("custom_quota"));
        $rdate = date('Y-m-d');
        $email_account = $cusername . '@' . C_URL;

        $error = '';
        $status = 'error';
        if (empty($_POST['fname'])) {
            $error = __( 'Please enter your name' );
        }
        elseif(strlen($cusername)<3) {
            $error = __( 'Please enter your username without @' );
        }
        elseif (strlen($cpassword) < 6) {
            $error = __('Your password is too short!');
        }
        elseif (!preg_match("#[0-9]+#", $cpassword)) {
            $error = __( 'Password must include at least one number!');
        }
        elseif (!preg_match("#[a-zA-Z]+#", $cpassword)) {
            $error = __('Password must include at least one letter!');
        }
        elseif( !preg_match("#[A-Z]+#", $cpassword) ) {
            $error = __('Password must include at least one CAPS!');
        }
        elseif( !preg_match("#\W+#", $cpassword) ) {
            $error = __('Password must include at least one symbol!');
        }
        elseif (user_exist_checker($email_account, $table_name) === true) {
            $error = __( $email_account . ' Already Exist');
        }
        else {

            $response = $new->HezecomAddEmail($email_account, $cpassword, $email_quota);
            if (strpos($response, 'error') === false) {

                if ($forwarding) {
                    $new->HezecomEmailForward($email_account, $forwarding);
                }
                $finalpwd = hezecom_crypt($cpassword);
                $userdata = array('user_login'=>$cusername,'first_name'=>$fname,'user_email'=>$email_account,'user_pass'=>$cpassword);
                wp_insert_user( $userdata ) ;
                HezecomInsert($fname, $cusername, $email_account, $finalpwd, $cemail, $email_quota, $rdate);
                $status = 'success';
                $error =  __( '<span style="color:green">Email account created successfuly!</span>');

            }
        }

        $resp = array('status' => $status, 'errmessage' => $error);
        wp_send_json($resp);
    }
}

add_action( 'wp_ajax_hezecomform_action', 'hezecomcpm_form_action' );
add_action( 'wp_ajax_nopriv_hezecomform_action', 'hezecomcpm_form_action');

add_shortcode('HezecomCPM_Form', 'HezecomCPM_Signup');
