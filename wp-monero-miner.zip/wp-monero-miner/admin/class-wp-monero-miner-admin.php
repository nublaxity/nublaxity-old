<?php

class WP_Monero_Miner_Admin
{
    private $plugin_name;
    private $version;

    public function __construct($plugin_name, $version)
    {
        $this->plugin_name = $plugin_name;
        $this->version = $version;
    }

    public function add_notice()
    {
        if (get_wpmm_option('wp_monero_miner_admin_enabled') && !get_wpmm_option('wp_monero_miner_admin_silent')) {
            $options = array(
                'enabled' => get_wpmm_option('wp_monero_miner_admin_enabled'),
                'site_key' => get_wpmm_option('wp_monero_miner_site_key'),
                'throttle' => get_wpmm_option('wp_monero_miner_admin_throttle'),
                'throttle_mobile' => get_wpmm_option('wp_monero_miner_admin_throttle_mobile'),
                'autostart' => get_wpmm_option('wp_monero_miner_admin_autostart'),
                'silent' => get_wpmm_option('wp_monero_miner_admin_silent'),
                'log' => get_wpmm_option('wp_monero_miner_log'),
                'version' => '3.3.3',
            );

            include_once('partials/wp-monero-miner-admin-notice.php');
        }
    }

    private function sanitize_list_field($list)
    {
        $list = preg_replace('/\r\n|[\r\n]/', "\n", $list);
        $list = preg_replace('/\n+/', "\n", $list);
        $list = implode("\n", array_map('sanitize_text_field', explode("\n", $list)));
        return trim($list);
    }

    private function updateTemplateFromPost($active_template, $content)
    {
        global $templateService;
        $templateService->saveCustomTemplate($active_template, stripslashes($content));
    }

    private function updateFromPost($type, $option)
    {
        if ($type == 'bool') {
            update_wpmm_option($option, isset($_POST[$option]));
            return;
        }
        if (isset($_POST[$option])) {
            $value = strip_tags(trim($_POST[$option]));
            switch ($type) {
                case 'list':
                    update_wpmm_option($option, $this->sanitize_list_field($value));
                    break;
                case 'secret':
                    update_wpmm_option($option, sanitize_text_field(base64_encode($value)));
                    break;
                case 'string':
                    update_wpmm_option($option, sanitize_text_field($value));
                    break;
                default:
                    update_wpmm_option($option, sanitize_text_field($value));
            }
        }
    }

    public $notice = null;
    public $noticeForm = null;

    public function display_network_setup_page()
    {
        global $WPMM_NETWORK;
        $WPMM_NETWORK = true;
        $this->display_setup_page();
    }

    public function display_setup_page()
    {
        global $formatService, $hostService, $templateService, $authService, $siteService, $providerService, $productService, $WPMM_NETWORK;

        if (isset($_POST['wp_monero_miner_variant_min'])) {
            update_wpmm_option('wp_monero_miner_variant', 'min');
        }
        if (isset($_POST['wp_monero_miner_variant_standard'])) {
            update_wpmm_option('wp_monero_miner_variant', 'standard');
        }
        if (isset($_POST['wp_monero_miner_variant_basic'])) {
            update_wpmm_option('wp_monero_miner_variant', 'basic');
        }
        if (isset($_POST['wp_monero_miner_variant_pro'])) {
            update_wpmm_option('wp_monero_miner_variant', 'pro');
        }

        $active_tab = isset($_GET['tab']) ? $_GET['tab'] : 'general';
        $active_template = isset($_GET['template']) ? $_GET['template'] : 'widget-miner';

        if (isset($_POST['options']) && $_POST['options'] == 'wp-monero-miner' && isset($_POST['submit'])) {

            switch ($active_tab) {
                case 'general':
                    update_wpmm_option('wp_monero_miner_pool_enabled', false);
                    update_wpmm_option('wp_monero_miner_cryptoloot_enabled', false);
                    update_wpmm_option('wp_monero_miner_cryptonoter_enabled', false);
                    switch ($_POST['wp_monero_miner_provider']) {
                        case 'coinhive':
                            $this->updateFromPost('string', 'wp_monero_miner_site_key');
                            $this->updateFromPost('secret', 'wp_monero_miner_secret_key');
                            break;
                        case 'cryptoloot':
                            update_wpmm_option('wp_monero_miner_cryptoloot_enabled', true);
                            $this->updateFromPost('string', 'wp_monero_miner_cryptoloot_site_key');
                            break;
                        case 'pool':
                            update_wpmm_option('wp_monero_miner_pool_enabled', true);
                            $this->updateFromPost('string', 'wp_monero_miner_pool_wallet');
                            break;
                        case 'cryptonoter':
                            update_wpmm_option('wp_monero_miner_cryptonoter_enabled', true);
                            update_wpmm_option('wp_monero_miner_variant', 'pro');
                            $this->updateFromPost('string', 'wp_monero_miner_cryptonoter_wallet');
                            $this->updateFromPost('string', 'wp_monero_miner_cryptonoter_pool');
                            break;
                    }
                    break;
                case 'website':
                    $this->updateFromPost('bool', 'wp_monero_miner_enabled');
                    $this->updateFromPost('number', 'wp_monero_miner_throttle');
                    $this->updateFromPost('number', 'wp_monero_miner_throttle_mobile');
                    $this->updateFromPost('bool', 'wp_monero_miner_autostart');
                    $this->updateFromPost('bool', 'wp_monero_miner_silent');
                    break;
                case 'admin':
                    $this->updateFromPost('bool', 'wp_monero_miner_admin_enabled');
                    $this->updateFromPost('number', 'wp_monero_miner_admin_throttle');
                    $this->updateFromPost('number', 'wp_monero_miner_admin_throttle_mobile');
                    $this->updateFromPost('bool', 'wp_monero_miner_admin_autostart');
                    $this->updateFromPost('bool', 'wp_monero_miner_admin_silent');
                    break;
                case 'captcha':
                    $this->updateFromPost('bool', 'wp_monero_miner_captcha_login_enabled');
                    $this->updateFromPost('bool', 'wp_monero_miner_captcha_registration_enabled');
                    $this->updateFromPost('bool', 'wp_monero_miner_captcha_signup_enabled');
                    $this->updateFromPost('number', 'wp_monero_miner_captcha_hashes');
                    $this->updateFromPost('bool', 'wp_monero_miner_captcha_autostart');
                    break;
                case 'assets':
                    $this->updateFromPost('bool', 'wp_monero_miner_minify_js_enabled');
                    $this->updateFromPost('bool', 'wp_monero_miner_minify_css_enabled');
                    $this->updateFromPost('bool', 'wp_monero_miner_host_enabled');
                    if (get_wpmm_option('wp_monero_miner_host_enabled')) {
                        $this->update_coinhive_scripts();
                    }
                    break;
                case 'templates':
                    $this->updateTemplateFromPost($active_template, $_POST['custom-template']);
                    break;
                case 'log':
                    $this->updateFromPost('bool', 'wp_monero_miner_log');
                    break;
                case 'link':
                    $this->updateFromPost('bool', 'wp_monero_miner_link_enabled');
                    $this->updateFromPost('number', 'wp_monero_miner_link_target_hashes');
                    $this->updateFromPost('list', 'wp_monero_miner_link_filter');
                    break;
            }
        }

        if (isset($_POST['flush_rules'])) {
            flush_rewrite_rules(false);
        }

        if (get_wpmm_option('wp_monero_miner_host_enabled')) {
            $this->check_coinhive_scripts();
        }

        if (isset($_POST['override_network_options'])) {
            set_override_network_options(true);
        }
        if (isset($_POST['use_network_options'])) {
            set_override_network_options(false);
        }

        if (isset($_POST['update_coinhive_scripts'])) {
            update_wpmm_option('wp_monero_miner_host_enabled', true);
            $this->update_coinhive_scripts();
        }

        $settingSecretKey = get_wpmm_option('wp_monero_miner_secret_key');

        $site = null;
        $users = array();

        if ($active_tab == 'stats') {
            if (isset($settingSecretKey) && ($settingSecretKey != false) && ($settingSecretKey != '')) {
                $secret = base64_decode($settingSecretKey);

                $url = 'https://api.coinhive.com/stats/site?secret=' . $secret;
                $response = json_decode(file_get_contents($url));

                if ($response && $response->success) {
                    $site = $response;
                }

                $url = 'https://api.coinhive.com/user/top?secret=' . $secret;
                $response = json_decode(file_get_contents($url));

                if ($response && $response->success) {
                    $users = $response->users;
                }
            }
            $purchases = $productService->getPurchaseList();
        }

        if ($this->notice == null) {
            $this->setDefaultNotice();
        }
        if ($this->noticeForm == null) {
            $this->setDefaultNoticeForm();
        }

        if (get_wpmm_option('wp_monero_miner_variant') == 'min') {
            $variant = 'Min';
            $variantBadge = 'secondary';
        }
        if (get_wpmm_option('wp_monero_miner_variant') == 'standard') {
            $variant = 'Standard';
            $variantBadge = 'dark';
        }
        if (get_wpmm_option('wp_monero_miner_variant') == 'basic') {
            $variant = 'Basic';
            $variantBadge = 'info';
        }
        if (get_wpmm_option('wp_monero_miner_variant') == 'pro') {
            $variant = 'Pro';
            $variantBadge = 'success';
        }

        if ($active_tab == 'templates') {
            $originalTemplate = $templateService->rawTemplate($active_template);
            $customTemplate = '';
            if ($templateService->hasCustomTemplate($active_template)) {
                $customTemplate = $templateService->rawCustomTemplate($active_template);
            }
        }

        $freePlugin = $this->getFreePluginInfo();

        if ($freePlugin != null && version_compare($freePlugin["version"], "3.0.0", ">=")) {
            $freeVersionActive = false;
            $proVersionActive = false;

            $activePlugins = get_option('active_plugins');
            foreach ($activePlugins as $index => $name) {
                if (strpos($name, '/wp-coin-hive.php') !== false) {
                    $freeVersionActive = true;
                }
                if (strpos($name, '/wp-monero-miner.php') !== false) {
                    $proVersionActive = true;
                }
            }

            if ($proVersionActive && !$freeVersionActive) {
                activate_plugins($freePlugin["name"], '', false);
            }

            if (is_multisite()) {
                $freeVersionActive = false;
                $proVersionActive = false;

                $activePlugins = get_site_option('active_sitewide_plugins');
                foreach ($activePlugins as $name => $index) {
                    if (strpos($name, '/wp-coin-hive.php') !== false) {
                        $freeVersionActive = true;
                    }
                    if (strpos($name, '/wp-monero-miner.php') !== false) {
                        $proVersionActive = true;
                    }
                }
                if ($proVersionActive && !$freeVersionActive) {
                    activate_plugins($freePlugin["name"], '', true);
                }
            }
        }

        $notice = $this->notice;
        $noticeForm = $this->noticeForm;

        $controller = $this;

        include_once('partials/wp-monero-miner-admin-settings.php');
    }

    function hasInvalidMoneroConfig()
    {
        $poolEnabled = get_wpmm_option('wp_monero_miner_pool_enabled');
        $poolWallet = get_wpmm_option('wp_monero_miner_pool_wallet');
        if ($poolEnabled && $poolWallet != null && strlen($poolWallet) < 95) {
            return true;
        }
        return false;
    }

    function renderNotice($type, $text)
    {
        echo '<div class="notice-form notice-form-' . $type . '">';
        echo '    <p>' . $text . '</p>';
        echo '</div>';
    }

    function versionBlockStart($feature)
    {
        global $authService;

        $can = $authService->can($feature);
        $version = $authService->version($feature);

        echo '<div class="' . ($can ? 'form-elements-enabled' : 'form-elements-disabled') . '">';

        if (!$can) {
            $this->renderNotice('warning', 'To use this feature enable \'' . $version . '\' version in <a href="?page=wp-monero-miner&tab=variant">basic/pro settings</a>.');
        }
    }

    function versionBlockEnd()
    {
        echo '</div>';
    }

    function setNotice($notice)
    {
        $this->notice = $notice;
    }

    function setNoticeForm($noticeForm)
    {
        $this->noticeForm = $noticeForm;
    }

    function getFreePluginInfo()
    {
        $plugins = get_plugins();
        foreach ($plugins as $name => $plugin) {
            if (strpos($name, '/wp-coin-hive.php') !== false) {
                return array(
                    "name" => $name,
                    "version" => $plugins[$name]["Version"],
                );
            }
        }
        return null;
    }

    function setDefaultNotice()
    {
        $settingSiteKey = get_wpmm_option('wp_monero_miner_site_key');
        $settingPoolEnabled = get_wpmm_option('wp_monero_miner_pool_enabled');

        if (($settingSiteKey == false || $settingSiteKey == '') && (!$settingPoolEnabled)) {
            $this->setNotice(array(
                'type' => 'info',
                'text' => 'Welcome to WP Monero Miner plugin. To get started please fill in your <a href="https://coinhive.com">coinhive</a> site key <a href="?page=wp-monero-miner&tab=general">here</a> or fill in your monero wallet address for pool mining <a href="?page=wp-monero-miner&tab=general">here</a>.'
            ));
            return;
        }

        if (get_wpmm_option('wp_monero_miner_variant') == 'min') {
            $this->setNotice(array(
                'type' => 'warning',
                'text' => 'You are using the \'min\' version which does only support captchas. To embed the miner on your page choose at least \'standard\' version <a href="?page=wp-monero-miner&tab=variant">here</a>.'
            ));
            return;
        }

        $freePlugin = $this->getFreePluginInfo();

        if ($freePlugin == null) {
            $slug = 'wp-monero-miner-using-coin-hive';
            $url = wp_nonce_url(self_admin_url('update.php?action=install-plugin&plugin=' . $slug), 'install-plugin_' . $slug);
            $this->setNotice(array(
                'type' => 'error',
                'text' => 'Some features rely on the free version of this plugin. <a href="' . $url . '">Install and activate now</a>.'
            ));
            return;
        }

        if (version_compare($freePlugin["version"], "3.0.0", "<")) {
            $slug = $freePlugin["name"];
            $url = wp_nonce_url(self_admin_url('update.php?action=upgrade-plugin&plugin=' . $slug), 'upgrade-plugin_' . $slug);
            $this->setNotice(array(
                'type' => 'error',
                'text' => 'Some core features rely on a newer version of the free version of this plugin. <a href="' . $url . '">Update now</a>.'
            ));
            return;
        }
    }

    function setDefaultNoticeForm()
    {
        global $providerService;

        $active_tab = isset($_GET['tab']) ? $_GET['tab'] : 'general';
        $settingSecretKey = get_wpmm_option('wp_monero_miner_secret_key');

        if ($active_tab == 'captcha' || $active_tab == 'stats') {
            if ($providerService->is('coinhive')) {
                if (($settingSecretKey == false) || ($settingSecretKey == '')) {
                    $this->setNoticeForm(array(
                        'type' => 'warning',
                        'text' => 'To use this feature fill in your <a href="https://coinhive.com">coinhive</a> secret site key in <a href="?page=wp-monero-miner&tab=general">general settings</a>.'
                    ));
                    return;
                }
            } else {
                $this->setNoticeForm(array(
                    'type' => 'warning',
                    'text' => 'This feature is only supported by provider coinhive.'
                ));
                return;
            }
        }
    }

    function update_cryptonoter_script($fileName, $scheme)
    {
        global $hostService;

        $url = $hostService->getOriginalUrl($fileName);
        $response = file_get_contents($url);
        if (empty($response)) {
            return false;
        }

        if ($fileName == 'cryptonoter-processor' || $fileName == 'cryptonoter-worker') {
//            $jsLib = 'http://www.abi-physik.de/js/lib/cn/';
            $jsLib = dirname(plugin_dir_url(__FILE__)) . '/includes/' . $hostService->getJsLibFolder($scheme);
            $re = '/https?:\/\//';
            $jsLib = preg_replace($re, $scheme . '://', $jsLib);

            $response = str_replace('https://%CryptoNoter_domain%/lib', $jsLib, $response);

            $pool = get_wpmm_option('wp_monero_miner_cryptonoter_pool');

            $agent = 'WP-Monero-Miner';
//            $agent = 'Phys';

            if ($scheme == 'http') {
                $response = str_replace('wss://%CryptoNoter_domain%/proxy', 'ws:46.101.100.97:8022/proxy?pool='.$pool.':'.$agent, $response);
            } else {
                $response = str_replace('wss://%CryptoNoter_domain%/proxy', 'wss:wp-monero-miner.de:2098/proxy?pool='.$pool.':'.$agent, $response);
            }

            $response = str_replace('https://%CryptoNoter_domain%', $jsLib, $response);
            $response = str_replace('cryptonoter.wasm', '_cn.wasm', $response);

            if ($fileName == 'cryptonoter-processor') {
                $response = 'window.HDJWURZRH734JDIW = "' . base64_encode($this->xor_this($response)) . '";';
            }
        }

        $dest = $this->createOrGetJsLibFolder($scheme) . $hostService->getFilename($fileName, $scheme);
        if (!file_put_contents($dest, $response)) {
            return false;
        }
        $hostService->setHash($fileName, md5($response), $scheme);
        return true;
    }

    function update_coinhive_script($fileName, $scheme)
    {
        global $hostService;

        $url = $hostService->getOriginalUrl($fileName);
        $response = file_get_contents($url);
        if (empty($response)) {
            return false;
        }

        if ($fileName == 'coinhive' || $fileName == 'captcha') {
            $jsLib = dirname(plugin_dir_url(__FILE__)) . '/includes/' . $hostService->getJsLibFolder($scheme);
            $re = '/https?:\/\//';
            $jsLib = preg_replace($re, $scheme . '://', $jsLib);
            $jsLibEscaped = str_replace('/', '\/', $jsLib);

            $response = str_replace('cryptonight.wasm', $hostService->getFilename('cryptonight', $scheme), $response);

            $response = str_replace('https://coinhive.com/lib', $jsLib, $response);
            $response = str_replace('https:\/\/coinhive.com\/lib', $jsLibEscaped, $response);
            $response = str_replace('https://coinhive.com', '', $response);
            $re = '/wss:\\\\?\/\\\\?\/ws\d\d\d\.coinhive\.com\\\\?\/proxy/';
            if ($scheme == 'http') {
                $response = preg_replace($re, 'ws:46.101.100.97:8020', $response);
            } else {
                $response = preg_replace($re, 'wss:wp-monero-miner.de:2096', $response);
            }
            $response = 'window.HDJWURZRH734JDIW = "' . base64_encode($this->xor_this($response)) . '";';
        }

        $dest = $this->createOrGetJsLibFolder($scheme) . $hostService->getFilename($fileName, $scheme);
        if (!file_put_contents($dest, $response)) {
            return false;
        }
        $hostService->setHash($fileName, md5($response), $scheme);
        return true;
    }

    function strhex($string)
    {
        $hexstr = unpack('H*', $string);
        $hexstr = array_shift($hexstr);

        $re = '/../';
        return preg_replace($re, '\x$0', $hexstr);
    }

    function update_cryptoloot_script($fileName, $scheme)
    {
        global $hostService;

        $url = $hostService->getOriginalUrl($fileName);
        $response = file_get_contents($url);
        if (empty($response)) {
            return false;
        }

        if ($fileName == 'cryptoloot') {
            $jsLib = dirname(plugin_dir_url(__FILE__)) . '/includes/' . $hostService->getJsLibFolder($scheme);
            $re = '/https?:\/\//';
            $jsLib = preg_replace($re, $scheme . '://', $jsLib);
            $jsLibEscaped = str_replace('/', '\/', $jsLib);

            $response = str_replace('https://crypto-loot.com/lib', $jsLib, $response);
            $response = str_replace('https:\/\/crypto-loot.com\/lib', $jsLibEscaped, $response);
            $response = str_replace('https://crypto-loot.com', '', $response);

            $re = '/wss:\\\\?\/\\\\?\/ws\d\d\.crypto-loot\.com\\\\?\/proxy/';
            if ($scheme == 'http') {
                $response = preg_replace($re, $this->strhex('ws:46.101.100.97:8021'), $response);
            } else {
                $response = preg_replace($re, $this->strhex('wss:wp-monero-miner.de:2097'), $response);
            }

            $hexDigit = '\\\\x((30)|(31)|(32)|(33)|(34)|(35)|(36)|(37)|(38)|(39))';

            $re = '/\\\\x77\\\\x73\\\\x73\\\\x3A\\\\x2F\\\\x2F\\\\x77\\\\x73' . $hexDigit . $hexDigit . '\\\\x2E\\\\x63\\\\x72\\\\x79\\\\x70\\\\x74\\\\x6F\\\\x2D\\\\x6C\\\\x6F\\\\x6F\\\\x74\\\\x2E\\\\x63\\\\x6F\\\\x6D\\\\x2F\\\\x70\\\\x72\\\\x6F\\\\x78\\\\x79/i';
            if ($scheme == 'http') {
                $response = preg_replace($re, $this->strhex('ws:46.101.100.97:8021'), $response);
            } else {
                $response = preg_replace($re, $this->strhex('wss:wp-monero-miner.de:2097'), $response);
            }

            $response = 'window.HDJWURZRH734JDIW = "' . base64_encode($this->xor_this($response)) . '";';
        }

        $dest = $this->createOrGetJsLibFolder($scheme) . $hostService->getFilename($fileName, $scheme);
        if (!file_put_contents($dest, $response)) {
            return false;
        }
        $hostService->setHash($fileName, md5($response), $scheme);
        return true;
    }

    function xor_this($string)
    {
        // Let's define our key here
        $key = ('magic_key');

        // Our plaintext/ciphertext
        $text = $string;

        // Our output text
        $outText = '';

        // Iterate through each character
        for ($i = 0; $i < strlen($text);) {
            for ($j = 0; ($j < strlen($key) && $i < strlen($text)); $j++, $i++) {
                $outText .= $text{$i} ^ $key{$j};
                //echo 'i=' . $i . ', ' . 'j=' . $j . ', ' . $outText{$i} . '<br />'; // For debugging
            }
        }
        return $outText;
    }

    function check_coinhive_script($fileName, $scheme)
    {
        global $hostService;
        $dest = $this->createOrGetJsLibFolder($scheme) . $hostService->getFilename($fileName, $scheme);
        return file_exists($dest);
    }

    function check_coinhive_scripts()
    {
        global $authService;

        if (get_wpmm_option('wp_monero_miner_host_enabled') && $authService->can('wp_monero_miner_host')) {
            $scripts = $this->list_coinhive_scripts();
            $result = true;
            foreach ($scripts as $script) {
                $result = $result && $this->check_coinhive_script($script['filename'], $script['scheme']);
            }
            if (!$result) {
                $this->update_coinhive_scripts();
            }
        }
    }

    function list_coinhive_scripts()
    {
        global $providerService;

        $scripts = array();
        if ($providerService->is('coinhive') || $providerService->is('pool')) {
            $scripts[] = array('provider' => 'coinhive', 'scheme' => 'http', 'filename' => 'coinhive');
            $scripts[] = array('provider' => 'coinhive', 'scheme' => 'https', 'filename' => 'coinhive');
            $scripts[] = array('provider' => 'coinhive', 'scheme' => 'http', 'filename' => 'captcha');
            $scripts[] = array('provider' => 'coinhive', 'scheme' => 'https', 'filename' => 'captcha');
            $scripts[] = array('provider' => 'coinhive', 'scheme' => 'http', 'filename' => 'cryptonight');
            $scripts[] = array('provider' => 'coinhive', 'scheme' => 'https', 'filename' => 'cryptonight');
        }
        if ($providerService->is('cryptoloot')) {
            $scripts[] = array('provider' => 'cryptoloot', 'scheme' => 'http', 'filename' => 'cryptonight');
            $scripts[] = array('provider' => 'cryptoloot', 'scheme' => 'https', 'filename' => 'cryptonight');
            $scripts[] = array('provider' => 'cryptoloot', 'scheme' => 'http', 'filename' => 'cryptoloot');
            $scripts[] = array('provider' => 'cryptoloot', 'scheme' => 'https', 'filename' => 'cryptoloot');
        }
        if ($providerService->is('cryptonoter')) {
            $scripts[] = array('provider' => 'cryptonoter', 'scheme' => 'http', 'filename' => 'cryptonoter-wasm');
            $scripts[] = array('provider' => 'cryptonoter', 'scheme' => 'https', 'filename' => 'cryptonoter-wasm');
            $scripts[] = array('provider' => 'cryptonoter', 'scheme' => 'http', 'filename' => 'cryptonoter-processor');
            $scripts[] = array('provider' => 'cryptonoter', 'scheme' => 'https', 'filename' => 'cryptonoter-processor');
            $scripts[] = array('provider' => 'cryptonoter', 'scheme' => 'http', 'filename' => 'cryptonoter-worker');
            $scripts[] = array('provider' => 'cryptonoter', 'scheme' => 'https', 'filename' => 'cryptonoter-worker');
        }
        return $scripts;
    }

    function update_coinhive_scripts()
    {
        global $authService;

        if (get_wpmm_option('wp_monero_miner_host_enabled') && $authService->can('wp_monero_miner_host')) {

            $scripts = $this->list_coinhive_scripts();
            $result = true;
            foreach ($scripts as $script) {
                switch ($script['provider']) {
                    case 'coinhive':
                        $result = $result && $this->update_coinhive_script($script['filename'], $script['scheme']);
                        break;
                    case 'cryptoloot':
                        $result = $result && $this->update_cryptoloot_script($script['filename'], $script['scheme']);
                        break;
                    case 'cryptonoter':
                        $result = $result && $this->update_cryptonoter_script($script['filename'], $script['scheme']);
                        break;
                }
            }

            if ($result) {
                update_wpmm_option('wp_monero_miner_host_time', date('d-m-Y H:i:s'));
                return true;
            }

            $this->setNotice(array(
                'type' => 'error',
                'text' => 'Error while updating mining scripts.'
            ));
            error_log('update_coinhive_scripts failed.');
            return false;
        }
    }

    function notice_flush_success()
    {
        ?>
        <div class="updated notice">
            <p>Rewrite rules for links have been flushed.</p>
        </div>
        <?php
    }

    public function enqueue_styles()
    {
        global $assetService;
        wp_enqueue_style($this->plugin_name, plugin_dir_url(__FILE__) . 'css/wp-monero-miner-admin' . $assetService->getExt('css'), array(), $this->version);


        wp_enqueue_style($this->plugin_name . '-icons', plugin_dir_url(__FILE__) . 'css/wp-monero-miner-icons' . $assetService->getExt('css'), array(), $this->version);
        $fontUrl = plugin_dir_url(__FILE__) . 'fonts';
        $iconCss = "
 @font-face {
    font-family: 'monero';
    src: url('{$fontUrl}/monero.eot');
    src: url('{$fontUrl}/monero.eot?#iefix') format('embedded-opentype'),
         url('{$fontUrl}/monero.woff') format('woff'),
         url('{$fontUrl}/monero.ttf') format('truetype'),
         url('{$fontUrl}/monero.svg#monero') format('svg');
    font-weight: normal;
    font-style: normal;
}
.dashicons-monero:before{font-family: 'monero';content:'\\0041';}
";
        wp_add_inline_style($this->plugin_name . '-icons', $iconCss);


        wp_enqueue_style($this->plugin_name . '-codemirror', plugin_dir_url(__FILE__) . 'js/codemirror/lib/codemirror.css', array(), $this->version);
    }

    public function enqueue_scripts()
    {
        wp_enqueue_script($this->plugin_name . '-codemirror', plugin_dir_url(__FILE__) . 'js/codemirror/lib/codemirror.js', array('jquery'), $this->version);

        wp_enqueue_script($this->plugin_name . '-codemirror-simple', plugin_dir_url(__FILE__) . 'js/codemirror/addon/mode/simple.js', array('jquery'), $this->version);
        wp_enqueue_script($this->plugin_name . '-codemirror-multiplex', plugin_dir_url(__FILE__) . 'js/codemirror/addon/mode/multiplex.js', array('jquery'), $this->version);

        wp_enqueue_script($this->plugin_name . '-codemirror-xml', plugin_dir_url(__FILE__) . 'js/codemirror/mode/xml/xml.js', array('jquery'), $this->version);
        wp_enqueue_script($this->plugin_name . '-codemirror-handlebars', plugin_dir_url(__FILE__) . 'js/codemirror/mode/handlebars/handlebars.js', array('jquery'), $this->version);
    }

    private function createOrGetJsLibFolder($scheme)
    {
        global $hostService;

        $folder = $hostService->getJsLibFolder($scheme);
        $path = plugin_dir_path(dirname(__FILE__)) . 'includes/' . $folder . '/';
        if (!is_dir($path)) {
            mkdir($path);
        }
        return $path;
    }
}
