<?php

add_filter('wp_head', 'fifu_add_js');
add_filter('wp_head', 'fifu_add_social_tags');
add_filter('wp_head', 'fifu_add_sirv_js');
add_filter('wp_head', 'fifu_apply_css');

function fifu_add_js() {
    wp_register_script('lazyload', plugins_url('/html/js/jquery.lazyloadxt.extra.js', __FILE__), array('jquery'));
    wp_enqueue_script('lazyload');
    include 'html/script.html';
}

function fifu_add_social_tags() {
    $post_id = get_the_ID();
    $url = fifu_main_image_url($post_id);
    $title = get_the_title($post_id);
    $description = wp_strip_all_tags(get_post_field('post_content', $post_id));

    if ($url && get_option('fifu_social') == 'toggleon')
        include 'html/social.html';
}

function fifu_add_sirv_js() {
    include_once(ABSPATH . 'wp-admin/includes/plugin.php');
    if (is_plugin_active('sirv/sirv.php')) {
        include 'html/sirv.html';
    }
}

function fifu_apply_css() {
    if (get_option('fifu_wc_lbox') == 'toggleoff')
        echo '<style>[class$="woocommerce-product-gallery__trigger"] {display:none !important;}</style>';
}

add_filter('post_thumbnail_html', 'fifu_replace', 10, 2);

function fifu_replace($html, $post_id) {
    if (is_singular('product'))
        return $html;

    $url = get_post_meta($post_id, 'fifu_image_url', true);
    $alt = get_post_meta($post_id, 'fifu_image_alt', true);

    return !$url || fifu_show_internal_instead_of_external($post_id) ? $html : fifu_get_html($url, $alt);
}

function is_ajax_call() {
    return (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest') || wp_doing_ajax();
}

function fifu_get_html($url, $alt) {
    include_once(ABSPATH . 'wp-admin/includes/plugin.php');
    if (is_plugin_active('sirv/sirv.php') && strpos($url, "sirv.com") !== false)
        return sprintf('<!-- Featured Image From URL plugin --> <img class="Sirv" data-src="%s">', $url);

    $css = get_option('fifu_css');

    if (fifu_should_hide()) {
        $css = 'display:none';
    }

    return sprintf('<!-- Featured Image From URL plugin --> <img %s alt="%s" title="%s" style="%s">', fifu_lazy_url($url), $alt, $alt, $css);
}

add_filter('the_content', 'fifu_add_to_content');

function fifu_add_to_content($content) {
    if (is_singular() && has_post_thumbnail() && get_option('fifu_content') == 'toggleon')
        return get_the_post_thumbnail() . $content;
    else
        return $content;
}

add_filter('wp_get_attachment_url', 'fifu_replace_attachment_url', 10, 2);

function fifu_replace_attachment_url($att_url, $att_id) {
    $post_id = strpos($att_id, 'fifu') !== false ? explode(':', $att_id)[1] : null;

    if (!$post_id)
        return $att_url;

    if (fifu_show_internal_instead_of_external($post_id))
        return $att_url;

    $url = fifu_main_image_url($post_id);

    return $url ? $url : $att_url;
}

add_filter('wp_get_attachment_image_src', 'fifu_replace_attachment_image_src', 10, 3);

function fifu_replace_attachment_image_src($image, $att_id, $size) {
    $post_id = strpos($att_id, 'fifu') !== false ? explode(':', $att_id)[1] : null;

    if (!$post_id)
        return $image;

    if (fifu_show_internal_instead_of_external($post_id))
        return $image;

    $url = fifu_main_image_url($post_id);
    if ($url) {
        $image_size = fifu_get_image_size($size);
        return array(
            $url,
            isset($image_size['width']) ? $image_size['width'] : 800,
            isset($image_size['height']) ? $image_size['height'] : 1,
            isset($image_size['crop']) ? $image_size['crop'] : '',
        );
    }
    return $image;
}

function fifu_should_hide() {
    return ((is_singular('post') && get_option('fifu_hide_post') == 'toggleon') || (is_singular('page') && get_option('fifu_hide_page') == 'toggleon'));
}

add_filter('genesis_get_image', 'fifu_genesis_image', 10, 4);

function fifu_genesis_image($args, $var1, $var2, $src) {
    return $src ? fifu_replace($args, get_the_ID()) : $args;
}

function fifu_main_image_url($post_id) {
    $url = get_post_meta($post_id, 'fifu_image_url', true);

    if (!$url && !fifu_has_internal_image($post_id))
        $url = get_option('fifu_default_url');

    return $url;
}

function fifu_lazy_url($url) {
    if (get_option('fifu_lazy') != 'toggleon' || is_ajax_call())
        return 'src="' . $url . '"';
    return (is_home() || (class_exists('WooCommerce') && is_shop()) ? 'data-src="' : 'src="') . $url . '"';
}

function fifu_has_internal_image($post_id) {
    $att_id = get_post_meta($post_id, '_thumbnail_id', true);
    return $att_id && strpos($att_id, "fifu") === false;
}

function fifu_show_internal_instead_of_external($post_id) {
    if (!fifu_has_internal_image($post_id))
        return false;
    return fifu_is_in_editor() || fifu_internal_priority();
}

function fifu_is_in_editor() {
    return !is_admin() || get_current_screen() == null ? false : get_current_screen()->parent_base == 'edit';
}

function fifu_internal_priority() {
    return get_option('fifu_priority') == 'toggleon';
}

function fifu_get_image_sizes() {
    global $_wp_additional_image_sizes;
    $sizes = array();
    foreach (get_intermediate_image_sizes() as $_size) {
        if (in_array($_size, array('thumbnail', 'medium', 'medium_large', 'large'))) {
            $sizes[$_size]['width'] = get_option("{$_size}_size_w");
            $sizes[$_size]['height'] = get_option("{$_size}_size_h");
            $sizes[$_size]['crop'] = (bool) get_option("{$_size}_crop");
        } elseif (isset($_wp_additional_image_sizes[$_size])) {
            $sizes[$_size] = array(
                'width' => $_wp_additional_image_sizes[$_size]['width'],
                'height' => $_wp_additional_image_sizes[$_size]['height'],
                'crop' => $_wp_additional_image_sizes[$_size]['crop'],
            );
        }
    }
    return $sizes;
}

function fifu_get_image_size($size) {
    $sizes = fifu_get_image_sizes();
    if (is_array($size)) {
        $arr_size = array();
        $arr_size['width'] = $size[0];
        $arr_size['height'] = $size[1];
        return $arr_size;
    }
    return isset($sizes[$size]) ? $sizes[$size] : false;
}

