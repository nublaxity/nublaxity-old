jQuery(document).ready(function ($) {
    disableClick($);
    setTimeout(function () {
        jQuery('div.flex-viewport').each(function (index) {
            jQuery(this).css('height', '');
        });
        resizeImg($);
    }, 500);
});

function disableClick($) {
    if ('<?php echo !fifu_woo_lbox(); ?>') {
        jQuery('.woocommerce-product-gallery__image').each(function (index) {
            jQuery(this).children().click(function () {
                return false;
            });
            jQuery(this).children().children().css("cursor", "default");
        });
    }
}

function resizeImg($) {
    jQuery("div.woocommerce-product-gallery").find('img').each(function (index) {
        //original size
        var width = $(this).context.clientWidth;
        var height = $(this).context.clientHeight;
        var ratio = width / height;
        jQuery(this).attr('data-large_image_width', jQuery(window).width() * ratio);
        jQuery(this).attr('data-large_image_height', jQuery(window).width());
    });
}

