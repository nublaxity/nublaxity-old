<?php

/*
 * Plugin Name: Featured Image From URL
 * Plugin URI: https://featuredimagefromurl.com/
 * Description: Use an external image as Featured Image of your post/page/custom post type (WooCommerce). Includes Auto Set (External Post), Product Gallery, Social Tags and more.
 * Version: 1.9.2
 * Author: Marcel Jacques Machado 
 * Author URI: https://www.linkedin.com/in/marceljm/
 */

define('FIFU_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('FIFU_INCLUDES_DIR', FIFU_PLUGIN_DIR . 'includes');
define('FIFU_ADMIN_DIR', FIFU_PLUGIN_DIR . 'admin');

require_once( FIFU_INCLUDES_DIR . '/thumbnail.php' );
require_once( FIFU_INCLUDES_DIR . '/thumbnail-category.php' );
require_once( FIFU_INCLUDES_DIR . '/external-post.php' );
require_once( FIFU_INCLUDES_DIR . '/convert-url.php' );
require_once (FIFU_INCLUDES_DIR . '/woo.php');

if (is_admin()) {
    require_once( FIFU_ADMIN_DIR . '/meta-box.php' );
    require_once( FIFU_ADMIN_DIR . '/menu.php' );
    require_once( FIFU_ADMIN_DIR . '/column.php' );
    require_once( FIFU_ADMIN_DIR . '/category.php' );
}

/* deactivate */

register_deactivation_hook(__FILE__, 'fifu_deactivate');

function fifu_deactivate($network_wide) {
    if (is_multisite() && $network_wide) {
        global $wpdb;
        foreach ($wpdb->get_col("SELECT blog_id FROM $wpdb->blogs") as $blog_id) {
            switch_to_blog($blog_id);
            fifu_delete_ids();
        }
    } else
        fifu_delete_ids();
}

function fifu_delete_ids() {
    global $wpdb;
    $table = $wpdb->prefix . 'postmeta';

    // new
    $query = "DELETE FROM " . $table . " WHERE meta_key = '_thumbnail_id' AND meta_value LIKE 'fifu:%'";
    $wpdb->query($query);

    // -1
    $where = array('meta_key' => '_thumbnail_id', 'meta_value' => -1);
    $wpdb->delete($table, $where);

    // fake
    $att_id = get_option('fifu_fake_attach_id');
    if ($att_id) {
        $where = array('meta_key' => '_thumbnail_id', 'meta_value' => $att_id);
        $wpdb->delete($table, $where);
        wp_delete_attachment($att_id);
        delete_option('fifu_fake_attach_id');
    }
}

/* activate */

register_activation_hook(__FILE__, 'fifu_activate');

function fifu_activate($network_wide) {
    if (is_multisite() && $network_wide) {
        global $wpdb;
        foreach ($wpdb->get_col("SELECT blog_id FROM $wpdb->blogs") as $blog_id) {
            switch_to_blog($blog_id);
            fifu_run_migration();
        }
    } else
        fifu_run_migration();
}

/* the code below is to migrate _thumbnail_id to a new format "fifu:post_id" */

if (!get_option('fifu_migration')) {
    fifu_run_migration();
}

function fifu_run_migration() {
    global $wpdb;

    // insert _thumbnail_id (new)
    $table = $wpdb->prefix . 'postmeta';
    $query = "
        SELECT DISTINCT post_id
        FROM " . $table . " a
        WHERE a.post_id in (
            SELECT post_id 
            FROM " . $table . " b 
            WHERE b.meta_key IN ('fifu_image_url', 'fifu_video_url', 'fifu_slider_image_url_0', 'fifu_shortcode')
            AND b.meta_value IS NOT NULL 
            AND b.meta_value <> ''
        )
        AND NOT EXISTS (
            SELECT 1 
            FROM " . $table . " c 
            WHERE a.post_id = c.post_id 
            AND c.meta_key = '_thumbnail_id'
        )";
    $result = $wpdb->get_results($query);
    foreach ($result as $i) {
        $data = array('post_id' => $i->post_id, 'meta_key' => '_thumbnail_id', 'meta_value' => 'fifu:' . $i->post_id);
        $wpdb->insert($table, $data);
    }

    // update _thumbnail_id (fake)
    $att_id = get_option('fifu_fake_attach_id');
    if ($att_id) {
        $table = $wpdb->prefix . 'postmeta';
        $query = "
	        SELECT DISTINCT post_id
	        FROM " . $table . " a
	        WHERE a.post_id in (
	            SELECT post_id 
	            FROM " . $table . " b 
	            WHERE b.meta_key IN ('fifu_image_url', 'fifu_video_url', 'fifu_slider_image_url_0', 'fifu_shortcode')
	            AND b.meta_value IS NOT NULL 
	            AND b.meta_value <> ''
	        )
	        AND EXISTS (
	            SELECT 1 
	            FROM " . $table . " c 
	            WHERE a.post_id = c.post_id 
	            AND c.meta_key = '_thumbnail_id'
	            AND c.meta_value = " . $att_id . "
	        )";
        $result = $wpdb->get_results($query);
        foreach ($result as $i) {
            $data = array('meta_value' => 'fifu:' . $i->post_id);
            $where = array('post_id' => $i->post_id, 'meta_key' => '_thumbnail_id', 'meta_value' => $att_id);
            $wpdb->update($table, $data, $where, null, null);
        }
    }

    // update _thumbnail_id (-1)
    $query = "
        SELECT post_id 
        FROM " . $table . " a
        WHERE a.meta_key IN ('fifu_image_url', 'fifu_video_url', 'fifu_slider_image_url_0', 'fifu_shortcode')
        AND a.meta_value IS NOT NULL 
        AND a.meta_value <> ''";
    $result = $wpdb->get_results($query);
    foreach ($result as $i) {
        $data = array('meta_value' => 'fifu:' . $i->post_id);
        $where = array('post_id' => $i->post_id, 'meta_key' => '_thumbnail_id', 'meta_value' => -1);
        $wpdb->update($table, $data, $where, null, null);
    }

    // migration control
    update_option('fifu_migration', true);
}

