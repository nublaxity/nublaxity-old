<?php return array(

	# Hidden fields
	'settings_saved_once' => '0',
	# General

	'display_on_post_types' => array('post' => 'on', 'page' => 'on'),
	'allow_edit_on_post_page' => 1,
	'enable_autocomplete' => 1,
	'global_class' => '',

); # config
