<?php

// this array holds variables that we dont want to have filtered by anyone

$this->hardcoded = array(
		
		'dont_filter' => array(
			
				'example_action' => 1,
			
		
		),
		
		
		'dont_execute_hooks' => array(
			
				'example_action_2'=> 1,
			
		
		),
		
		
		
		
		
		
);


?>