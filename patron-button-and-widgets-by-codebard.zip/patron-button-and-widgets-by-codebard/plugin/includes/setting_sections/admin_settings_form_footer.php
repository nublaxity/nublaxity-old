<div id="{***prefix***}admin_settings_form_footer">

<button type="submit" class="cb_p6_admin_button">{%%%save%%%}</button>
			<input type="hidden" name="{***id***}_action" value="save_settings">
			<input type="hidden" name="{***id***}_tab" value="{***tab***}">

		</form>

</div>