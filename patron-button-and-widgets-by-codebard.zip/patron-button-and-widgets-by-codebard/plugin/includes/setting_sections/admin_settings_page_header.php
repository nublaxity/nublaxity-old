<div class="{***prefix***}settings">

	<div style="display:table;vertical-align:middle;">
		<div style="display:inline-block;vertical-align:middle;"><a href="https://codebard.com" target="_blank"><img src="{***plugin_url***}images/logo-small.png" /></a></div>

		<div style="display:inline-block;vertical-align:middle;padding-left: 20px;"><h1>{%%%plugin_name%%%}</h1></div>
	</div>

	