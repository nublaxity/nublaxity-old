<hr width="100%">

<div class="cb_p6_h2"><?php echo $this->lang['admin_page_support_title']; ?></div>
	<div class="cb_p6_admin_info"><?php echo $this->lang['admin_page_support_explanation']; ?>
	
	<a href="https://codebard.com/support" target="_blank"><?php echo $this->lang['admin_page_support_link']; ?></a>
	</div>
	<hr width="100%">
	
	
	<div class="cb_p6_h2"><?php echo $this->lang['news_and_info_title']; ?></div>
	<div class="cb_p6_admin_info"><?php echo $this->lang['news_and_info_title_explanation']; ?>

	<a href="http://codebard.us9.list-manage.com/subscribe?u=5afbc1be9f2ed76070f4b64fd&id=d24515a258"><?php echo $this->lang['join_mailing_list_link']; ?></a>
	
	</div>
	<br><br>
