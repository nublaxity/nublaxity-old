<hr width="100%">
<?php

	if($this->check_addon_exists('patron_plugin_pro')=='notinstalled')
	{
?>
	<div class="cb_p6_h2">Patron Plugin Pro</div>
	<div class="cb_p6_admin_info">Increase your Patrons and Monthly income by using all features of Patreon!
	
	<a href="https://codebard.com/patron-plugin-pro" target="_blank">Buy & Download Here</a>
	</div>
	<hr width="100%">	
	
	
<?php	
	}
	
?>
	<div class="cb_p6_h2">WooCommerce Support System</div>
	<div class="cb_p6_admin_info">Easy and Professional support ticket system for WooCommerce.
	
	<a href="https://codebard.com/codebard-help-desk-woocommerce-integration" target="_blank">Buy & Download Here</a>
	</div>
	<hr width="100%">
	<div class="cb_p6_h2">CodeBard Help Desk</div>
	<div class="cb_p6_admin_info">Full featured support ticket system for WordPress. Multi Language, Unlimited Departments, Unlimited Agents.
	
	<a href="https://codebard.com/codebard-help-desk-for-wordpress" target="_blank">Download Here</a>
	</div>
	<hr width="100%">
	<div class="cb_p6_h2"><?php echo $this->lang['admin_rapier_title']; ?></div>
	<div class="cb_p6_admin_info"><?php echo $this->lang['admin_rapier_info']; ?>
	
	<a href="http://codebard.com/rapier-wordpress-theme" target="_blank"><?php echo $this->lang['admin_rapier_link_text']; ?></a>
	</div>
	<hr width="100%">
<div class="cb_p6_h2"><?php echo $this->lang['extras_join_affiliates_title']; ?></div>
	<div class="cb_p6_admin_info"><?php echo $this->lang['extras_join_affiliates_explanation']; ?>
	
	<a href="http://codebard.com/affiliates" target="_blank"><?php echo $this->lang['admin_page_affiliate_link_label']; ?></a>
	</div>
	<hr width="100%">
	