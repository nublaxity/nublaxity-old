<?php
// Prevents outside access to the plugin folder
?>