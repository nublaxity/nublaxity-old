<?php
/**
 * Do not put custom translations here. They will be deleted on Mashshare updates.
 *
 * Keep custom MASHSB translations in /wp-content/languages/mashsb/
 */