<?php
if ( ! defined( 'myCRED_VERSION' ) ) exit;
