jQuery(document).ready(function()
{
	jQuery("#trap").remove(); 
});