<?php
// Silence is golden. And I agree :)
?>